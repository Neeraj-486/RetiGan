"""Central settings. Override the data location with the RETI_DATA env var."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("RETI_DATA", ROOT / "data"))
RAW_DIR = DATA_DIR / "raw"              # put APTOS 2019 train images here
PROC_DIR = DATA_DIR / "processed"       # generated dataset + meta.csv
RUNS_DIR = ROOT / "runs"                # checkpoints + histories
RESULTS_DIR = ROOT / "results"          # json results + figures

IMG = 128                               # image size (DCGAN native size)
SEED = 42                               # data split / data generation seed
SEEDS = [42, 43, 44]                    # model seeds -> every result is mean +/- std over these
N_REAL = 2000                           # real images used from the raw folder
PREPROC_MODES = ["none", "clahe", "ben"]
DEFAULT_PREPROC = "clahe"
