"""Image preparation shared by the demo, the checker and add_generator."""
from . import config
from .utils import preprocess_bgr, apply_circle


def prepare_bgr(img, size=config.IMG):
    """Already size x size (a 128 px generated image, or one of our processed PNGs)? Do NOT crop/resize again:
    resampling would smear exactly the pixel-level artifacts the detector looks for.
    Anything else (photos, big images): full preprocessing (crop border, pad square, resize, circle mask)."""
    if img.shape[0] == size and img.shape[1] == size:
        return apply_circle(img)
    return preprocess_bgr(img, size)
