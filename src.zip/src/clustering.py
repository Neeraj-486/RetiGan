"""Course Exp 7: pre-trained VGG-16 as a feature extractor + clustering of fundus images.
Do real / GAN / manipulated images separate in ImageNet-feature space, WITHOUT any training on our labels?

    python -m src.clustering --arch vgg16 --seed 42
Outputs results/clustering.json (ARI / NMI / purity) and results/figs/vgg16_tsne.png
(if VGG fails to load on your timm version, try --arch resnet50)."""
import argparse, json
import numpy as np, cv2, pandas as pd, torch, torch.nn.functional as F, timm, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score
from . import config
from .utils import seed_all, get_device, apply_preproc, MEAN, STD


@torch.no_grad()
def extract(model, paths, preproc, dev, bs=64):
    out = []
    for i in range(0, len(paths), bs):
        ims = [apply_preproc(cv2.imread(str(config.PROC_DIR / p)), preproc) for p in paths[i:i + bs]]
        x = torch.from_numpy(np.stack([(cv2.cvtColor(im, cv2.COLOR_BGR2RGB) / 255.0 - MEAN) / STD for im in ims]).astype(np.float32))
        x = F.interpolate(x.permute(0, 3, 1, 2), size=224, mode="bilinear", align_corners=False).to(dev)
        f = model(x)[-1].mean((2, 3))                 # last conv feature map -> global average pool
        out.append(f.cpu().numpy())
    return np.concatenate(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arch", default="vgg16")
    ap.add_argument("--per_class", type=int, default=300)
    ap.add_argument("--preproc", default=config.DEFAULT_PREPROC)
    ap.add_argument("--seed", type=int, default=config.SEED)
    a = ap.parse_args()
    seed_all(a.seed); dev = get_device()
    df = pd.read_csv(config.PROC_DIR / "meta.csv")
    te = df[df["split"] == "test"]
    classes = [c for c in ["real", "gan", "manip"] + sorted(c for c in te["cls"].unique() if str(c).startswith("ext_")) if c in set(te["cls"])]
    paths, labels = [], []
    for k, c in enumerate(classes):
        p = list(te[te["cls"] == c]["path"][:a.per_class]); paths += p; labels += [k] * len(p)
    labels = np.array(labels)
    model = timm.create_model(a.arch, pretrained=True, features_only=True).to(dev).eval()
    X = extract(model, paths, a.preproc, dev)
    Xs = PCA(n_components=min(50, X.shape[1], len(X) - 1), random_state=a.seed).fit_transform(StandardScaler().fit_transform(X))
    km = KMeans(n_clusters=len(classes), n_init=10, random_state=a.seed).fit(Xs)
    purity = sum(np.bincount(labels[km.labels_ == c]).max() for c in range(len(classes)) if (km.labels_ == c).any()) / len(labels)
    res = {"arch": a.arch, "classes": classes, "n": int(len(labels)), "preproc": a.preproc,
           "ARI": float(adjusted_rand_score(labels, km.labels_)), "NMI": float(normalized_mutual_info_score(labels, km.labels_)),
           "purity": float(purity)}
    json.dump(res, open(config.RESULTS_DIR / "clustering.json", "w"), indent=1); print(res)

    emb = TSNE(n_components=2, perplexity=30, init="pca", random_state=a.seed).fit_transform(Xs)
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.5))
    for k, c in enumerate(classes):
        ax[0].scatter(*emb[labels == k].T, s=8, label=c, alpha=.7)
    ax[0].set_title(f"{a.arch} features - true classes (t-SNE)"); ax[0].legend()
    sc = ax[1].scatter(*emb.T, c=km.labels_, s=8, cmap="tab10"); ax[1].set_title(f"k-means clusters (k={len(classes)}), ARI={res['ARI']:.2f}")
    for x in ax:
        x.set_xticks([]); x.set_yticks([])
    plt.tight_layout(); (config.RESULTS_DIR / "figs").mkdir(parents=True, exist_ok=True)
    plt.savefig(config.RESULTS_DIR / "figs" / f"{a.arch}_tsne.png", dpi=140)


if __name__ == "__main__":
    main()
