"""Debug why an image is classified the way it is, using exactly the dashboard pipeline.
   python -m src.check_image path/to/image.png [more images] [--ckpt runs/full_s42/best.pt]
Prints the model's probabilities for your image next to what the model does on 40 known real / GAN / edited test images,
and saves check_<name>.png = the 128 px image the model actually sees."""
import argparse
from pathlib import Path
import cv2, numpy as np, pandas as pd, torch
from . import config
from .evaluate import load_model
from .utils import apply_preproc, bgr_to_tensor, get_device
from .prep import prepare_bgr


def predict(model, info, img, dev):
    base = prepare_bgr(img, config.IMG)
    x = bgr_to_tensor(apply_preproc(base, info["preproc"]), info["mean"], info["std"])[None].to(dev)
    with torch.no_grad():
        p = torch.softmax(model(x)["logits"].float(), 1)[0].cpu().numpy()
    return p, base


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("images", nargs="*")
    ap.add_argument("--ckpt", default=None)
    ap.add_argument("--n", type=int, default=40)
    a = ap.parse_args()
    ck = a.ckpt or str(sorted(config.RUNS_DIR.glob("full_s*/best.pt"))[0])
    dev = get_device()
    model, info = load_model(ck, dev)
    classes = info["classes"]; ri = classes.index("real")
    print("model:", ck, "| classes:", classes)

    meta = pd.read_csv(config.PROC_DIR / "meta.csv").fillna("")
    ref = {}
    print("\nREFERENCE: what the model does on known test images (same pipeline)")
    for c in [c for c in ["real", "gan", "manip"] if c in classes]:
        paths = list(meta[(meta["split"] == "test") & (meta["cls"] == c)]["path"][:a.n])
        P = np.stack([predict(model, info, cv2.imread(str(config.PROC_DIR / p)), dev)[0] for p in paths])
        pf = 1 - P[:, ri]; ref[c] = pf
        counts = {k: int((P.argmax(1) == i).sum()) for i, k in enumerate(classes)}
        print(f"  true {c:6s}: predicted as {counts} | median P(fake) = {np.median(pf):.2f}")

    for path in a.images:
        if Path(path).is_dir():                       # a whole folder: report how many are flagged
            fs = sorted(f for f in Path(path).iterdir() if f.suffix.lower() in (".png", ".jpg", ".jpeg"))
            P = np.stack([predict(model, info, cv2.imread(str(f)), dev)[0] for f in fs if cv2.imread(str(f)) is not None])
            pf = 1 - P[:, ri]
            counts = {k: int((P.argmax(1) == i).sum()) for i, k in enumerate(classes)}
            print(f"\nFOLDER: {path}  ({len(P)} images)")
            print(f"  predicted as {counts}")
            print(f"  flagged as fake (P(fake) >= 0.5): {100 * (pf >= 0.5).mean():.0f}%   | median P(fake) = {np.median(pf):.2f}")
            continue
        img = cv2.imread(path)
        if img is None:
            print(f"\n{path}: cannot read"); continue
        p, base = predict(model, info, img, dev)
        out = f"check_{Path(path).stem}.png"; cv2.imwrite(out, base)
        pf = 1 - p[ri]
        print(f"\nYOUR IMAGE: {path}  (original size {img.shape[1]}x{img.shape[0]})")
        print("  probabilities:", {c: round(float(v), 3) for c, v in zip(classes, p)})
        print(f"  P(fake) = {pf:.2f}   (real test images: median {np.median(ref['real']):.2f}, "
              f"GAN test images: median {np.median(ref['gan']):.2f})" if "gan" in ref else f"  P(fake) = {pf:.2f}")
        print(f"  saved {out}  <- open it: this is what the model sees. It should look like the training images (round retina, black corners).")


if __name__ == "__main__":
    main()
