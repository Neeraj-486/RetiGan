"""Qualitative figure: image | ground-truth mask | predicted mask | Grad-CAM.
   python -m src.visualize --ckpt runs/full_s42/best.pt"""
import argparse
import cv2, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from . import config
from .dataset import FundusDS
from .evaluate import load_model, run_name
from .explain import analyze, overlay
from .utils import get_device


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--per_class", type=int, default=3)
    a = ap.parse_args()
    dev = get_device()
    model, info = load_model(a.ckpt, dev)
    classes = info["classes"]
    ds = FundusDS("test", classes, preproc=info["preproc"], aug="none", mean=info["mean"], std=info["std"])
    picks = []
    for c in classes:
        picks += list(ds.df.index[ds.df["cls"] == c][:a.per_class])
    fig, ax = plt.subplots(4, len(picks), figsize=(2.3 * len(picks), 9.5))
    for k, idx in enumerate(picks):
        x, m, y, _ = ds[idx]
        img = cv2.imread(str(config.PROC_DIR / ds.df.iloc[idx]["path"]))
        r = analyze(model, x[None].to(dev))
        rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        ax[0, k].imshow(rgb); ax[0, k].set_title(f"true: {classes[y]}\npred: {classes[r['pred']]}", fontsize=8)
        ax[1, k].imshow(overlay(img, m[0].numpy(), 0.5))
        ax[2, k].imshow(overlay(img, r["mask"], 0.5) if r["mask"] is not None else rgb)
        ax[3, k].imshow(overlay(img, r["cam"], 0.5))
        for j in range(4):
            ax[j, k].axis("off")
    for j, t in enumerate(["input", "ground-truth edit", "predicted edit map", "Grad-CAM"]):
        ax[j, 0].text(-0.08, 0.5, t, transform=ax[j, 0].transAxes, rotation=90, va="center", ha="right", fontsize=9)
    plt.tight_layout()
    out = config.RESULTS_DIR / "figs" / f"qualitative_{run_name(a.ckpt)}.png"
    out.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out, dpi=140); print("saved", out)


if __name__ == "__main__":
    main()
