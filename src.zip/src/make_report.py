"""Aggregate results/*.json (+ run histories) into tables and figures.   python -m src.make_report
All model numbers are mean +/- std over seeds."""
import json, re
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from . import config
from .metrics import fake_scores, threshold_table

NUM = ["acc", "f1", "auc", "auc_real_vs_fake", "dice", "iou"]
MAIN_ORDER = ["baseline_cnn", "baseline_resnet_small", "baseline_resnet", "baseline_effnetb0", "rgb_freq", "rgb_mask", "full"]
FT_ORDER = ["ft_scratch", "ft_frozen", "baseline_resnet"]
REG_ORDER = ["reg_none", "reg_dropout", "reg_wd", "reg_aug", "reg_es", "reg_all"]
PRE_ORDER = ["pre_none", "pre_clahe", "pre_ben"]
ROB_ORDER = ["clean", "jpeg=90", "jpeg=70", "jpeg=50", "resize=0.75", "resize=0.5", "noise=3", "noise=8"]


def base_of(name):
    return re.sub(r"_s\d+$", "", name)


def load_results():
    """Returns (per-run summary df, robustness df, per-manipulation df, raw json list)."""
    raw = [json.load(open(p)) for p in sorted(config.RESULTS_DIR.glob("*__*.json"))]
    summ, rob, kinds = [], [], []
    for d in raw:
        base = d.get("base", base_of(d["name"])); loc = d.get("localization") or {}
        summ.append({"model": d["name"], "base": base, "seed": d.get("seed"), "eval": d["tag"], "n": d.get("n"),
                     **d["metrics"], "dice": loc.get("dice"), "iou": loc.get("iou")})
        for cond, m in (d.get("robustness") or {}).items():
            rob.append({"model": d["name"], "base": base, "condition": cond, **m})
        for k, m in (d.get("per_kind") or {}).items():
            kinds.append({"model": d["name"], "base": base, "eval": d["tag"], "manipulation": k, **m})
    return pd.DataFrame(summ), pd.DataFrame(rob), pd.DataFrame(kinds), raw


def aggregate(summ):
    """mean/std over seeds per (base, eval). Returns (numeric df, display df with 'mean ± std' strings)."""
    cols = [c for c in NUM if c in summ.columns]
    g = summ.groupby(["base", "eval"])[cols]
    out = g.mean().add_suffix("_mean").join(g.std(ddof=0).fillna(0).add_suffix("_std")).join(g.size().rename("seeds")).reset_index()
    disp = out[["base", "eval", "seeds"]].copy()
    for c in cols:
        disp[c] = ["" if pd.isna(m) else f"{m:.3f} ± {s:.3f}" for m, s in zip(out[c + "_mean"], out[c + "_std"])]
    return out, disp


def hist(name):
    p = config.RUNS_DIR / name / "history.json"
    return json.load(open(p)) if p.exists() else None


def seed0():
    return config.SEEDS[0]


def order_rows(df, order, col="base"):
    df = df[df[col].isin(order)].copy()
    df[col] = pd.Categorical(df[col], order, ordered=True)
    return df.sort_values(col)


def reg_table(summ):
    rows = []
    for b in REG_ORDER:
        h = hist(f"{b}_s{seed0()}")
        if not h:
            continue
        t = summ[(summ["base"] == b) & (summ["eval"] == "test")]
        rows.append({"setting": b, "epochs_run": len(h), "train_acc": h[-1]["train_acc"], "val_acc": h[-1]["val_acc"],
                     "gap(train-val)": round(h[-1]["train_acc"] - h[-1]["val_acc"], 4),
                     "test_acc": round(float(t["acc"].mean()), 4) if len(t) else None,
                     "test_f1": round(float(t["f1"].mean()), 4) if len(t) else None})
    return pd.DataFrame(rows)


def roc_for(base):
    """ROC data from the first seed's saved predictions (real vs any fake)."""
    from sklearn.metrics import roc_curve, roc_auc_score
    p = config.RESULTS_DIR / "preds" / f"{base}_s{seed0()}__test.npz"
    if not p.exists():
        return None
    d = np.load(p); s = fake_scores(d["P"]); y = d["Y"] != 0
    fpr, tpr, _ = roc_curve(y, s)
    return fpr, tpr, float(roc_auc_score(y, s)), s, y


def psi_of(cls):
    """ext_stylegan -> 1.0 ; ext_stylegan_t07 -> 0.7 ; ext_stylegan_t05 -> 0.5 (truncation psi encoded in the class name)."""
    m = re.search(r"_t(\d+)$", cls)
    return int(m.group(1)) / 10 if m else 1.0


def main():
    summ, rob, kinds, _ = load_results()
    if summ.empty:
        raise SystemExit("no results yet - run run_experiments.py first")
    R, F = config.RESULTS_DIR, config.RESULTS_DIR / "figs"; F.mkdir(parents=True, exist_ok=True)
    agg, disp = aggregate(summ)
    summ.to_csv(R / "summary_per_run.csv", index=False); agg.to_csv(R / "summary_agg.csv", index=False)
    try:
        md = disp.to_markdown(index=False)
    except ImportError:
        md = disp.to_string(index=False)
    open(R / "summary.md", "w").write(md); print(disp.to_string(index=False))

    # E1/E2: main comparison with error bars
    m = order_rows(agg[agg["eval"] == "test"], MAIN_ORDER)
    if not m.empty:
        x = np.arange(len(m)); w = 0.27
        plt.figure(figsize=(9, 4))
        for i, c in enumerate(["acc", "f1", "auc"]):
            if c + "_mean" in m:
                plt.bar(x + (i - 1) * w, m[c + "_mean"], w, yerr=m[c + "_std"], label=c, capsize=2)
        plt.xticks(x, m["base"], rotation=30, ha="right"); plt.ylim(0, 1.05); plt.legend(); plt.grid(axis="y", alpha=.3)
        plt.title("Main comparison on test (mean ± std over seeds)"); plt.tight_layout(); plt.savefig(F / "main_comparison.png", dpi=140); plt.close()
        m.to_csv(R / "table_main.csv", index=False)

    # fine-tuning study (CO4)
    ft = order_rows(disp[disp["eval"] == "test"], FT_ORDER)
    if len(ft) > 1:
        ft.to_csv(R / "table_finetuning.csv", index=False)

    # preprocessing ablation
    pre = order_rows(disp[disp["eval"] == "test"], PRE_ORDER)
    if not pre.empty:
        pre.to_csv(R / "table_preprocessing.csv", index=False)

    # cross-generator generalization
    cg = disp[disp["base"].str.startswith("cg_")]
    if not cg.empty:
        cg.to_csv(R / "table_cross_generator.csv", index=False)

    # external generators (e.g. StyleGAN): detection of fakes from a generator never seen in training
    ex = summ[summ["eval"].str.startswith("cross_real-ext_")].copy()
    if not ex.empty:
        ex["generator"] = ex["eval"].str.replace("cross_real-", "", regex=False)
        g = ex.groupby(["base", "generator"])[["acc", "auc"]]
        tab = g.mean().add_suffix("_mean").join(g.std(ddof=0).fillna(0).add_suffix("_std")).reset_index()
        tab.to_csv(R / "table_external_generators.csv", index=False)
        sg = ex[ex["generator"].str.startswith("ext_stylegan")].copy()
        if not sg.empty:
            sg["psi"] = sg["generator"].map(psi_of)
            plt.figure(figsize=(6, 4))
            for b, gd in sg.groupby("base"):
                mm = gd.groupby("psi")["auc"].mean()
                plt.plot(mm.index, mm.values, marker="o", label=b)
            plt.xlabel("StyleGAN truncation psi (lower = cleaner, less diverse fakes)"); plt.ylabel("AUC real vs StyleGAN fake")
            plt.grid(alpha=.3); plt.legend(fontsize=8); plt.title("Detecting an UNSEEN generator vs truncation")
            plt.tight_layout(); plt.savefig(F / "stylegan_truncation.png", dpi=140); plt.close()

    # robustness (mean over seeds)
    if not rob.empty:
        rob.to_csv(R / "robustness_per_run.csv", index=False)
        g = rob.groupby(["base", "condition"])["acc"]
        mean, std = g.mean().unstack(), g.std(ddof=0).fillna(0).unstack()
        order = [c for c in ROB_ORDER if c in mean.columns]
        plt.figure(figsize=(7.5, 4))
        for b in mean.index:
            plt.errorbar(range(len(order)), mean.loc[b, order], yerr=std.loc[b, order], marker="o", capsize=2, label=b)
        plt.xticks(range(len(order)), order, rotation=30); plt.ylabel("accuracy"); plt.grid(alpha=.3); plt.legend(fontsize=7)
        plt.title("Robustness to degradations"); plt.tight_layout(); plt.savefig(F / "robustness.png", dpi=140); plt.close()
        mean[order].round(4).to_csv(R / "table_robustness.csv")

    # per-manipulation (mean over seeds)
    if not kinds.empty:
        num = [c for c in ["detect_recall", "dice", "iou"] if c in kinds.columns]
        kinds.groupby(["base", "eval", "manipulation"])[num].mean().round(4).reset_index().to_csv(R / "table_per_manipulation.csv", index=False)

    # Exp 2: ROC + threshold analysis
    plt.figure(figsize=(5, 4.5)); have = False; tt = None
    for b in ["baseline_cnn", "baseline_resnet", "full"]:
        r = roc_for(b)
        if r:
            have = True; plt.plot(r[0], r[1], label=f"{b} (AUC {r[2]:.3f})")
            if b == "full":
                tt = pd.DataFrame(threshold_table(r[3], r[4]))
    if have:
        plt.plot([0, 1], [0, 1], "k--", alpha=.4); plt.xlabel("false positive rate (real flagged fake)"); plt.ylabel("true positive rate (fake caught)")
        plt.title("ROC: real vs any fake"); plt.legend(fontsize=8); plt.grid(alpha=.3); plt.tight_layout(); plt.savefig(F / "roc.png", dpi=140)
    plt.close()
    if tt is not None:
        tt.to_csv(R / "threshold_table_full.csv", index=False)
        plt.figure(figsize=(6, 4))
        for c in ["tpr", "fpr", "precision", "f1"]:
            plt.plot(tt["threshold"], tt[c], label=c)
        plt.xlabel("decision threshold on P(fake)"); plt.legend(); plt.grid(alpha=.3); plt.title("Threshold sweep (full model)")
        plt.tight_layout(); plt.savefig(F / "threshold_sweep.png", dpi=140); plt.close()

    # Exp 1: convergence vs number of epochs, and loss vs architecture
    conv = [(e, hist(f"conv_e{e}_s{seed0()}")) for e in (1, 2, 3, 5, 10, 20)]
    conv = [(e, h) for e, h in conv if h]
    if conv:
        fig, ax = plt.subplots(1, 2, figsize=(10, 3.8))
        for e, h in conv:
            ax[0].plot([x["epoch"] for x in h], [x["val_loss"] for x in h], marker="o", ms=3, label=f"{e} epochs")
            ax[1].plot([x["epoch"] for x in h], [x["val_acc"] for x in h], marker="o", ms=3, label=f"{e} epochs")
        ax[0].set_title("validation loss"); ax[1].set_title("validation accuracy")
        for a_ in ax:
            a_.set_xlabel("epoch"); a_.grid(alpha=.3); a_.legend(fontsize=8)
        plt.suptitle("Convergence vs number of epochs (ResNet-50)"); plt.tight_layout(); plt.savefig(F / "convergence_epochs.png", dpi=140); plt.close()
    arch = [(b, hist(f"{b}_s{seed0()}")) for b in ["baseline_cnn", "baseline_resnet_small", "baseline_resnet", "baseline_effnetb0"]]
    arch = [(b, h) for b, h in arch if h]
    if arch:
        fig, ax = plt.subplots(1, 2, figsize=(10, 3.8))
        for b, h in arch:
            ax[0].plot([x["epoch"] for x in h], [x["train_loss"] for x in h], label=b)
            ax[1].plot([x["epoch"] for x in h], [x["val_loss"] for x in h], label=b)
        ax[0].set_title("training loss"); ax[1].set_title("validation loss")
        for a_ in ax:
            a_.set_xlabel("epoch"); a_.grid(alpha=.3); a_.legend(fontsize=8)
        plt.suptitle("Loss vs network architecture"); plt.tight_layout(); plt.savefig(F / "convergence_arch.png", dpi=140); plt.close()

    # CO3: regularization
    rt = reg_table(summ)
    if not rt.empty:
        rt.to_csv(R / "table_regularization.csv", index=False); print(rt.to_string(index=False))
        fig, ax = plt.subplots(1, 2, figsize=(10, 3.8))
        for b in ["reg_none", "reg_all"]:
            h = hist(f"{b}_s{seed0()}")
            if h:
                ax[0].plot([x["epoch"] for x in h], [x["train_loss"] for x in h], "--", label=f"{b} train")
                ax[0].plot([x["epoch"] for x in h], [x["val_loss"] for x in h], label=f"{b} val")
        ax[0].set_title("train vs val loss"); ax[0].legend(fontsize=8); ax[0].grid(alpha=.3); ax[0].set_xlabel("epoch")
        ax[1].bar(rt["setting"], rt["gap(train-val)"]); ax[1].set_title("train-val accuracy gap (overfitting)"); ax[1].tick_params(axis="x", rotation=30)
        plt.tight_layout(); plt.savefig(F / "regularization.png", dpi=140); plt.close()
    print("saved tables + figures in", R)


if __name__ == "__main__":
    main()
