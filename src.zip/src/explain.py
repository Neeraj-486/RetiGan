"""Explainability helpers shared by the report scripts and the dashboard."""
import cv2, numpy as np, torch, torch.nn.functional as F


def analyze(model, x, target=None):
    """x: 1x3xHxW tensor. Returns class probs, Grad-CAM heatmap, predicted manipulation mask (or None)."""
    model.eval(); model.zero_grad()
    out = model(x)
    logits, feat = out["logits"], out["feat"]
    feat.retain_grad()
    probs = torch.softmax(logits, 1)[0].detach().cpu().numpy()
    t = int(probs.argmax()) if target is None else int(target)
    logits[0, t].backward()
    w = feat.grad.mean((2, 3), keepdim=True)
    cam = torch.relu((w * feat).sum(1, keepdim=True))
    cam = F.interpolate(cam, size=x.shape[2:], mode="bilinear", align_corners=False)[0, 0]
    cam = ((cam - cam.min()) / (cam.max() - cam.min() + 1e-8)).detach().cpu().numpy()
    mask = torch.sigmoid(out["mask"])[0, 0].detach().cpu().numpy() if "mask" in out else None
    return {"probs": probs, "pred": t, "cam": cam, "mask": mask}


def overlay(img_bgr, heat, alpha=0.45):
    """Blend a 0..1 heatmap on a BGR image; returns RGB for display."""
    h = cv2.applyColorMap((np.clip(heat, 0, 1) * 255).astype(np.uint8), cv2.COLORMAP_JET)
    return cv2.cvtColor(cv2.addWeighted(img_bgr, 1 - alpha, h, alpha, 0), cv2.COLOR_BGR2RGB)


def spectrum_image(img_bgr):
    """Log-magnitude Fourier spectrum as a displayable RGB image (GAN artifacts show as grid/star patterns)."""
    g = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY).astype(np.float32)
    s = np.log1p(np.abs(np.fft.fftshift(np.fft.fft2(g))))
    s = (255 * (s - s.min()) / (s.max() - s.min() + 1e-8)).astype(np.uint8)
    return cv2.cvtColor(s, cv2.COLOR_GRAY2RGB)
