"""Generate fundus images with a PUBLIC diffusion model: a different generator family than our DCGAN.
   python -m pip install diffusers accelerate          (once)
   python -m src.gen_ddpm --n 16 --out ddpm_test        (quick timing test)
   python -m src.gen_ddpm --n 300 --out ddpm_images
Model: GS-23/ddpm-unet-retinal-fundus-image-generator on Hugging Face (MIT licence, 128x128 DDPM).
Uses the faster DDIM sampler (--steps 50) instead of the full 1000 DDPM steps."""
import argparse, time
from pathlib import Path
import torch
from .utils import get_device


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="GS-23/ddpm-unet-retinal-fundus-image-generator")
    ap.add_argument("--n", type=int, default=300)
    ap.add_argument("--bs", type=int, default=16)
    ap.add_argument("--steps", type=int, default=50)
    ap.add_argument("--out", default="ddpm_images")
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()
    from diffusers import DDPMPipeline, DDIMPipeline, DDIMScheduler
    dev = get_device()
    base = DDPMPipeline.from_pretrained(a.model)
    pipe = DDIMPipeline(unet=base.unet, scheduler=DDIMScheduler.from_config(base.scheduler.config)).to(dev)
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    g = torch.Generator().manual_seed(a.seed)
    done, t0 = 0, time.time()
    while done < a.n:
        k = min(a.bs, a.n - done)
        for im in pipe(batch_size=k, generator=g, num_inference_steps=a.steps).images:
            im.convert("RGB").save(out / f"ddpm_{done:05d}.png"); done += 1
        print(f"{done}/{a.n}  elapsed {time.time() - t0:.0f}s", flush=True)
    print("saved to", out)


if __name__ == "__main__":
    main()
