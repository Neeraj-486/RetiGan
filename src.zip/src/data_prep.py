"""Step 1: build the real + manipulated dataset (with pixel masks) and meta.csv.

    python -m src.data_prep            # uses data/raw
Pipeline: crop border -> pad square -> resize -> retina circle mask -> quality filter -> leak-free split ->
5 manipulation types with masks. Everything saved as lossless PNG (no file-format shortcut).
Splits are made on REAL source images first; manipulations are created inside each split,
so no source image ever leaks across train/val/test.  Seeded with config.SEED.
"""
import argparse, glob, json, os
import numpy as np, cv2, pandas as pd
from sklearn.model_selection import train_test_split
from . import config
from .utils import preprocess_bgr, quality_ok

KINDS = ["lesion_remove", "lesion_add", "splice", "blur", "copymove"]


def make_manip(img, other, rng, size):
    """Local edit inside a feathered circle placed INSIDE the retina. Returns (edited, binary mask, kind)."""
    kind = str(rng.choice(KINDS))
    r = int(rng.integers(size // 12, size // 5))
    ang, rad = rng.uniform(0, 2 * np.pi), np.sqrt(rng.uniform(0, 1)) * (size / 2 - r - 8)
    cx, cy = int(size / 2 + rad * np.cos(ang)), int(size / 2 + rad * np.sin(ang))
    hard = np.zeros((size, size), np.uint8)
    cv2.circle(hard, (cx, cy), r, 255, -1)
    if kind == "lesion_remove":                      # erase structure (inpainting)
        src = cv2.inpaint(img, hard, 3, cv2.INPAINT_TELEA)
    elif kind == "lesion_add":                       # fake exudate-like bright lesion
        col = np.clip(np.array([120, 200, 230]) + rng.normal(0, 10, 3), 0, 255).astype(np.uint8)
        src = np.empty_like(img); src[:] = col
    elif kind == "splice":                           # patch from another eye
        src = other
    elif kind == "blur":                             # local smoothing
        src = cv2.GaussianBlur(img, (0, 0), 5)
    else:                                            # copymove (source patch must lie on the retina)
        for _ in range(8):
            dx = int(rng.choice([-1, 1]) * rng.integers(20, size // 2))
            dy = int(rng.choice([-1, 1]) * rng.integers(20, size // 2))
            src = np.roll(img, (dy, dx), (0, 1))
            if src[hard > 0].mean() > 25:
                break
    alpha = cv2.GaussianBlur(hard, (0, 0), 2).astype(np.float32)[..., None] / 255
    out = (img.astype(np.float32) * (1 - alpha) + src.astype(np.float32) * alpha).astype(np.uint8)
    return out, hard, kind


def build(raw_dir, n_real, size):
    files = []
    for ext in ("png", "jpg", "jpeg"):
        files += glob.glob(os.path.join(str(raw_dir), f"*.{ext}"))
    files = sorted(files)
    if not files:
        raise SystemExit(f"No images found in {raw_dir}. Put the APTOS images there first.")
    rng = np.random.default_rng(config.SEED)
    files = [files[i] for i in rng.permutation(len(files))[:n_real]]
    tr, tmp = train_test_split(files, test_size=0.3, random_state=config.SEED)
    va, te = train_test_split(tmp, test_size=0.5, random_state=config.SEED)

    P = config.PROC_DIR
    for old in P.glob("stats_*.json"):               # normalization stats must be recomputed for new data
        old.unlink()
    rows, report = [], {"seed": config.SEED, "size": size, "dropped_quality": 0, "unreadable": 0, "splits": {}}
    for sp, fl in {"train": tr, "val": va, "test": te}.items():
        for c in ("real", "manip"):
            (P / sp / c).mkdir(parents=True, exist_ok=True)
        (P / "masks" / sp).mkdir(parents=True, exist_ok=True)
        imgs, srcs = [], []
        for f in fl:
            im = cv2.imread(f)
            if im is None:
                report["unreadable"] += 1; continue
            im = preprocess_bgr(im, size)
            if quality_ok(im):
                imgs.append(im); srcs.append(os.path.basename(f))
            else:
                report["dropped_quality"] += 1
        for i, img in enumerate(imgs):
            j = int(rng.integers(len(imgs) - 1)); j += j >= i       # a different image, same split
            m_img, mask, kind = make_manip(img, imgs[j], rng, size)
            rp, mp, kp = f"{sp}/real/{i:05d}.png", f"{sp}/manip/{i:05d}.png", f"masks/{sp}/{i:05d}.png"
            cv2.imwrite(str(P / rp), img)
            cv2.imwrite(str(P / mp), m_img)
            cv2.imwrite(str(P / kp), mask)
            rows.append(dict(split=sp, cls="real", path=rp, mask_path="", kind="", src=srcs[i]))
            rows.append(dict(split=sp, cls="manip", path=mp, mask_path=kp, kind=kind, src=srcs[i]))
        report["splits"][sp] = len(imgs)
        print(f"{sp}: {len(imgs)} real + {len(imgs)} manipulated")
    print(f"dropped by quality filter: {report['dropped_quality']}, unreadable: {report['unreadable']}")
    pd.DataFrame(rows).to_csv(P / "meta.csv", index=False)
    json.dump(report, open(P / "data_report.json", "w"), indent=1)
    print("wrote", P / "meta.csv")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default=str(config.RAW_DIR))
    ap.add_argument("--n_real", type=int, default=config.N_REAL)
    ap.add_argument("--size", type=int, default=config.IMG)
    a = ap.parse_args()
    build(a.raw, a.n_real, a.size)
