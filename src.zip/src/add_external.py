"""OPTIONAL but valuable: add fakes from ANOTHER generator as a TEST-ONLY class (true cross-generator test).

    python -m src.add_external --dir path/to/diffusion_fundus_pngs --name diffusion --n 300
Creates class 'ext_<name>' (test split only). run_experiments.py evaluates the cross-generator models on it automatically.
"""
import argparse, glob, os
import cv2, pandas as pd
from . import config
from .utils import preprocess_bgr

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True)
    ap.add_argument("--name", required=True)
    ap.add_argument("--n", type=int, default=300)
    a = ap.parse_args()
    P = config.PROC_DIR
    cls = f"ext_{a.name}"
    files = sorted(sum([glob.glob(os.path.join(a.dir, f"*.{e}")) for e in ("png", "jpg", "jpeg")], []))[:a.n]
    (P / "test" / cls).mkdir(parents=True, exist_ok=True)
    rows = []
    for i, f in enumerate(files):
        im = cv2.imread(f)
        if im is None:
            continue
        rel = f"test/{cls}/{i:05d}.png"
        cv2.imwrite(str(P / rel), preprocess_bgr(im, config.IMG))
        rows.append(dict(split="test", cls=cls, path=rel, mask_path="", kind=""))
    df = pd.read_csv(P / "meta.csv").fillna("")
    df = df[df["cls"] != cls]
    pd.concat([df, pd.DataFrame(rows)]).to_csv(P / "meta.csv", index=False)
    print(f"added {len(rows)} images as class {cls}")
