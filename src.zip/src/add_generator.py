"""Add images from ANOTHER generator to the dataset as class 'gan' (= AI-generated), split 70/15/15.
   python -m src.add_generator --dir ddpm_images --name ddpm
Run it BEFORE retraining. Re-running replaces the earlier images of the same --name."""
import argparse, glob, os
import numpy as np, cv2, pandas as pd
from . import config
from .prep import prepare_bgr


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True)
    ap.add_argument("--name", required=True)
    ap.add_argument("--n", type=int, default=100000)
    a = ap.parse_args()
    P = config.PROC_DIR
    files = sorted(sum([glob.glob(os.path.join(a.dir, f"*.{e}")) for e in ("png", "jpg", "jpeg")], []))[:a.n]
    if not files:
        raise SystemExit(f"no images in {a.dir}")
    order = np.random.default_rng(config.SEED).permutation(len(files))
    n_tr, n_va = int(0.7 * len(files)), int(0.15 * len(files))
    split_of = {int(i): ("train" if r < n_tr else "val" if r < n_tr + n_va else "test") for r, i in enumerate(order)}
    df = pd.read_csv(P / "meta.csv").fillna("")
    df = df[~df["path"].str.contains(f"/gan/{a.name}_", regex=False)]          # allow re-run
    rows, counts = [], {"train": 0, "val": 0, "test": 0}
    for i, f in enumerate(files):
        im = cv2.imread(f)
        if im is None:
            continue
        sp = split_of[i]; rel = f"{sp}/gan/{a.name}_{i:05d}.png"
        (P / sp / "gan").mkdir(parents=True, exist_ok=True)
        cv2.imwrite(str(P / rel), prepare_bgr(im, config.IMG))
        row = {c: "" for c in df.columns}; row.update(split=sp, cls="gan", path=rel)
        if "src" in row:
            row["src"] = f"gen:{a.name}"
        rows.append(row); counts[sp] += 1
    pd.concat([df, pd.DataFrame(rows)]).to_csv(P / "meta.csv", index=False)
    print(f"added {len(rows)} images as class 'gan':", counts)


if __name__ == "__main__":
    main()
