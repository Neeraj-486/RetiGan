"""Export the TRAIN-split real fundus images at 256px, as training data for StyleGAN2-ADA fine-tuning.
Only train images are exported (val/test never reach the generator), so the cross-generator test stays leak-free.

    python -m src.stylegan_data --size 256 --out stylegan/dataset256
Uses the original raw file (via meta.csv 'src' column) for best quality; falls back to upsampling the 128px copy."""
import argparse
from pathlib import Path
import cv2, pandas as pd
from . import config
from .utils import preprocess_bgr


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--size", type=int, default=256, help="must be a power of 2; 256 matches the ffhq256 source network")
    ap.add_argument("--out", default=str(config.ROOT / "stylegan" / "dataset256"))
    a = ap.parse_args()
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(config.PROC_DIR / "meta.csv").fillna("")
    tr = df[(df["split"] == "train") & (df["cls"] == "real")]
    n_raw = n_up = 0
    for i, (_, r) in enumerate(tr.iterrows()):
        raw = config.RAW_DIR / r["src"] if r.get("src", "") else None
        if raw is not None and raw.exists():
            img = preprocess_bgr(cv2.imread(str(raw)), a.size); n_raw += 1
        else:
            img = cv2.resize(cv2.imread(str(config.PROC_DIR / r["path"])), (a.size, a.size), interpolation=cv2.INTER_CUBIC); n_up += 1
        cv2.imwrite(str(out / f"{i:05d}.png"), img)
    print(f"wrote {n_raw + n_up} images to {out}  (from raw: {n_raw}, upsampled from 128px: {n_up})")


if __name__ == "__main__":
    main()
