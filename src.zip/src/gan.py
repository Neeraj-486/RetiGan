"""Train a DCGAN on TRAIN real images only, then generate fake fundus images (course Exp 9 / CO5).

    python -m src.gan --epochs 300
Outputs: class 'gan' for every split in meta.csv, loss curves, sample grid, and a simple mode-collapse check.
(Swap in a stronger generator later: drop its PNGs into processed/<split>/gan and add rows to meta.csv.)
"""
import argparse, json, random, time
import numpy as np, cv2, pandas as pd, torch, torch.nn as nn, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from . import config
from .utils import seed_all, get_device


class Gen(nn.Module):
    def __init__(self, nz=100, nf=64):
        super().__init__()
        def up(i, o):
            return [nn.ConvTranspose2d(i, o, 4, 2, 1, bias=False), nn.BatchNorm2d(o), nn.ReLU(True)]
        self.nz = nz
        self.net = nn.Sequential(
            nn.ConvTranspose2d(nz, nf * 16, 4, 1, 0, bias=False), nn.BatchNorm2d(nf * 16), nn.ReLU(True),  # 4x4
            *up(nf * 16, nf * 8), *up(nf * 8, nf * 4), *up(nf * 4, nf * 2), *up(nf * 2, nf),                # 64x64
            nn.ConvTranspose2d(nf, 3, 4, 2, 1, bias=False), nn.Tanh())                                       # 128x128

    def forward(self, z):
        return self.net(z.view(-1, self.nz, 1, 1))


class Disc(nn.Module):
    def __init__(self, nf=64):
        super().__init__()
        def blk(i, o, bn=True):
            return [nn.Conv2d(i, o, 4, 2, 1, bias=False)] + ([nn.BatchNorm2d(o)] if bn else []) + [nn.LeakyReLU(0.2, True)]
        self.net = nn.Sequential(*blk(3, nf, False), *blk(nf, nf * 2), *blk(nf * 2, nf * 4),
                                 *blk(nf * 4, nf * 8), *blk(nf * 8, nf * 16),
                                 nn.Conv2d(nf * 16, 1, 4, 1, 0, bias=False))

    def forward(self, x):
        return self.net(x).view(-1)


def mean_pair_dist(imgs, rng, pairs=400):
    """Mean normalized L2 distance between random image pairs: a crude diversity score (low => mode collapse)."""
    flat = imgs.reshape(len(imgs), -1).astype(np.float32) / 255.0
    i, j = rng.integers(0, len(flat), pairs), rng.integers(0, len(flat), pairs)
    keep = i != j
    return float(np.linalg.norm(flat[i[keep]] - flat[j[keep]], axis=1).mean() / np.sqrt(flat.shape[1]))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=300)
    ap.add_argument("--bs", type=int, default=64)
    ap.add_argument("--nf", type=int, default=64, help="base channel width; use 32 for a faster smoke run")
    ap.add_argument("--seed", type=int, default=config.SEED)
    a = ap.parse_args()
    assert config.IMG == 128, "this DCGAN is built for 128x128 images"
    seed_all(a.seed); dev = get_device()
    P = config.PROC_DIR
    df = pd.read_csv(P / "meta.csv").fillna("")
    tr = df[(df["split"] == "train") & (df["cls"] == "real")]
    real_u8 = np.stack([cv2.imread(str(P / p)) for p in tr["path"]])               # BGR everywhere
    data = torch.from_numpy(real_u8.astype(np.float32) / 127.5 - 1).permute(0, 3, 1, 2)
    print("training GAN on", len(data), "real train images on", dev)

    G, D = Gen(nf=a.nf).to(dev), Disc(nf=a.nf).to(dev)
    oG = torch.optim.Adam(G.parameters(), 2e-4, betas=(0.5, 0.999))
    oD = torch.optim.Adam(D.parameters(), 2e-4, betas=(0.5, 0.999))
    bce = nn.BCEWithLogitsLoss()
    gen = torch.Generator().manual_seed(a.seed)
    losses = {"D": [], "G": []}
    t_start = time.time()
    for ep in range(a.epochs):
        perm = torch.randperm(len(data), generator=gen)
        dsum = gsum = 0.0; steps = 0
        for i in range(0, len(data) - a.bs + 1, a.bs):
            real = data[perm[i:i + a.bs]].to(dev)
            if random.random() < 0.5:
                real = real.flip(3)
            fake = G(torch.randn(a.bs, 100, device=dev))
            lD = bce(D(real), torch.full((a.bs,), 0.9, device=dev)) + bce(D(fake.detach()), torch.zeros(a.bs, device=dev))
            oD.zero_grad(); lD.backward(); oD.step()
            lG = bce(D(fake), torch.ones(a.bs, device=dev))
            oG.zero_grad(); lG.backward(); oG.step()
            dsum += lD.item(); gsum += lG.item(); steps += 1
        losses["D"].append(dsum / steps); losses["G"].append(gsum / steps)
        if ep % 25 == 0 or ep == a.epochs - 1:
            print(f"epoch {ep:4d}  D {losses['D'][-1]:.3f}  G {losses['G'][-1]:.3f}  elapsed {time.time() - t_start:.0f}s", flush=True)

    (config.RUNS_DIR / "dcgan").mkdir(parents=True, exist_ok=True)
    torch.save(G.state_dict(), config.RUNS_DIR / "dcgan" / "G.pt")
    json.dump(losses, open(config.RUNS_DIR / "dcgan" / "losses.json", "w"))
    G.eval()
    df = df[df["cls"] != "gan"]                       # allow re-running
    rows, gen_train = [], None
    with torch.no_grad():
        for sp in ("train", "val", "test"):
            n = int(((df["split"] == sp) & (df["cls"] == "real")).sum())
            (P / sp / "gan").mkdir(parents=True, exist_ok=True)
            out = []
            for s in range(0, n, 100):
                z = torch.randn(min(100, n - s), 100, device=dev)
                imgs = ((G(z).cpu().permute(0, 2, 3, 1).numpy() + 1) * 127.5).clip(0, 255).astype(np.uint8)
                for j, im in enumerate(imgs):
                    rel = f"{sp}/gan/{s + j:05d}.png"
                    cv2.imwrite(str(P / rel), im)
                    rows.append(dict(split=sp, cls="gan", path=rel, mask_path="", kind=""))
                out.append(imgs)
            if sp == "train":
                gen_train = np.concatenate(out)
    pd.concat([df, pd.DataFrame(rows)]).to_csv(P / "meta.csv", index=False)

    # --- CO5 material: loss curves, samples, diversity (mode-collapse) check
    figs = config.RESULTS_DIR / "figs"; figs.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(6, 3.5)); plt.plot(losses["D"], label="discriminator"); plt.plot(losses["G"], label="generator")
    plt.xlabel("epoch"); plt.ylabel("loss"); plt.title("DCGAN training losses"); plt.legend(); plt.grid(alpha=.3)
    plt.tight_layout(); plt.savefig(figs / "gan_losses.png", dpi=140); plt.close()
    k = 8
    grid = np.vstack([np.hstack(list(real_u8[:k])), np.hstack(list(gen_train[:k]))])
    cv2.imwrite(str(figs / "gan_samples.png"), cv2.resize(grid, None, fx=1.5, fy=1.5))   # top: real, bottom: GAN
    rng = np.random.default_rng(a.seed)
    stats = {"diversity_real": mean_pair_dist(real_u8[:300], rng), "diversity_gan": mean_pair_dist(gen_train[:300], rng)}
    stats["diversity_ratio"] = stats["diversity_gan"] / max(stats["diversity_real"], 1e-9)
    stats["note"] = "ratio well below 1 suggests mode collapse (generator covers only part of the real distribution)"
    json.dump(stats, open(config.RUNS_DIR / "dcgan" / "gan_stats.json", "w"), indent=1)
    print("generated", len(rows), "GAN images;", {k: round(v, 3) for k, v in stats.items() if k != "note"})


if __name__ == "__main__":
    main()
