"""Evaluate a checkpoint on the test split (optionally robustness + other class sets).

   python -m src.evaluate --ckpt runs/full_s42/best.pt --robust
   python -m src.evaluate --ckpt runs/cg_rgb_gan_s42/best.pt --classes real,manip     # cross-generator
Writes results/<run>__<tag>.json and results/preds/<run>__<tag>.npz (probabilities for ROC / threshold analysis)."""
import argparse, json, re
import numpy as np, torch
from . import config
from .dataset import FundusDS
from .models import RetiForGAN
from .metrics import infer, cls_metrics, loc_metrics
from .utils import get_device

ROBUST = [("jpeg", 90), ("jpeg", 70), ("jpeg", 50), ("resize", 0.75), ("resize", 0.5), ("noise", 3), ("noise", 8)]


def load_model(path, device):
    """Returns (model in eval mode, info dict with classes / cfg / preproc / mean / std / seed)."""
    ck = torch.load(path, map_location=device, weights_only=False)      # our own checkpoints
    c = ck["cfg"]
    m = RetiForGAN(c["arch"], c["num_classes"], c["use_freq"], c["use_mask"], pretrained=False, dropout=c.get("dropout", 0.3))
    m.load_state_dict(ck["state"]); m.to(device).eval()
    info = {"classes": ck["classes"], "cfg": c, "preproc": ck.get("preproc", "none"),
            "mean": ck.get("mean"), "std": ck.get("std"), "seed": ck.get("seed")}
    return m, info


def run_name(ckpt):
    return str(ckpt).replace("\\", "/").split("/")[-2]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--classes", default=None, help="evaluation classes (default: those used in training)")
    ap.add_argument("--tag", default=None)
    ap.add_argument("--split", default="test")
    ap.add_argument("--robust", action="store_true")
    a = ap.parse_args()

    dev = get_device()
    model, info = load_model(a.ckpt, dev)
    train_classes, cfg = info["classes"], info["cfg"]
    classes = a.classes.split(",") if a.classes else train_classes
    assert len(classes) == cfg["num_classes"], "evaluation classes must match the model's output size"
    name = run_name(a.ckpt)
    tag = a.tag or ("test" if classes == train_classes else "cross_" + "-".join(classes))
    kw = dict(preproc=info["preproc"], aug="none", mean=info["mean"], std=info["std"])

    ds = FundusDS(a.split, classes, **kw)
    P, Y, M, G = infer(model, ds, dev)
    met, conf = cls_metrics(P, Y, classes)
    loc, per_kind = loc_metrics(M, G, ds.df, classes, P)
    base = re.sub(r"_s\d+$", "", name)
    res = {"name": name, "base": base, "seed": info["seed"], "tag": tag, "classes": classes, "cfg": cfg,
           "preproc": info["preproc"], "n": int(len(Y)), "metrics": met, "confusion": conf,
           "localization": loc, "per_kind": per_kind}
    print(name, tag, met, "loc:", loc)

    if a.robust:
        res["robustness"] = {}
        for kind, val in [("clean", 0)] + ROBUST:
            d = FundusDS(a.split, classes, pert=None if kind == "clean" else (kind, val), **kw)
            Pp, Yp, Mp, Gp = infer(model, d, dev)
            m, _ = cls_metrics(Pp, Yp, classes)
            l, _ = loc_metrics(Mp, Gp, d.df, classes, Pp)
            key = "clean" if kind == "clean" else f"{kind}={val}"
            res["robustness"][key] = {**m, **({"dice": l["dice"]} if l else {})}
            print("  ", key, res["robustness"][key])

    config.RESULTS_DIR.mkdir(exist_ok=True); (config.RESULTS_DIR / "preds").mkdir(exist_ok=True)
    json.dump(res, open(config.RESULTS_DIR / f"{name}__{tag}.json", "w"), indent=1)
    np.savez(config.RESULTS_DIR / "preds" / f"{name}__{tag}.npz", P=P, Y=Y, classes=np.array(classes))
    print("saved", config.RESULTS_DIR / f"{name}__{tag}.json")


if __name__ == "__main__":
    main()
