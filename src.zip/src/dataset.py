import json, cv2, numpy as np, pandas as pd, torch
from torch.utils.data import Dataset
from . import config
from .utils import perturb, apply_preproc, bgr_to_tensor


def get_stats(preproc, n=500):
    """Dataset-specific per-channel mean/std (RGB, 0..1) of the TRAIN real images after `preproc`. Cached."""
    p = config.PROC_DIR / f"stats_{preproc}.json"
    if p.exists():
        d = json.load(open(p)); return d["mean"], d["std"]
    df = pd.read_csv(config.PROC_DIR / "meta.csv")
    tr = df[(df["split"] == "train") & (df["cls"] == "real")].head(n)
    s1 = np.zeros(3); s2 = np.zeros(3); cnt = 0
    for pth in tr["path"]:
        im = apply_preproc(cv2.imread(str(config.PROC_DIR / pth)), preproc)
        px = cv2.cvtColor(im, cv2.COLOR_BGR2RGB).reshape(-1, 3).astype(np.float64) / 255.0
        s1 += px.sum(0); s2 += (px ** 2).sum(0); cnt += len(px)
    mean = s1 / cnt; std = np.sqrt(s2 / cnt - mean ** 2)
    out = {"mean": [float(v) for v in mean], "std": [float(v) for v in std]}
    json.dump(out, open(p, "w")); return out["mean"], out["std"]


class FundusDS(Dataset):
    """Reads meta.csv. `classes` order defines label ids, e.g. ['real','gan','manip'] or ['real','manip'].
    Pipeline: load base image -> [perturb] -> [augment] -> preproc (none|clahe|ben) -> normalize.
    aug: none | flip | strong (flip + rotation +-20deg + brightness/contrast jitter). Never blur/resize/JPEG
    in training augmentation: those would destroy the very artifacts we want to detect.
    Returns: image tensor, mask (1xHxW), label, has_mask (1 for real/manip, 0 for fully synthetic)."""

    def __init__(self, split, classes, train=False, pert=None, preproc=config.DEFAULT_PREPROC,
                 aug="flip", mean=None, std=None):
        df = pd.read_csv(config.PROC_DIR / "meta.csv").fillna("")
        self.df = df[(df["split"] == split) & (df["cls"].isin(classes))].reset_index(drop=True)
        self.cmap = {c: i for i, c in enumerate(classes)}
        self.train, self.pert, self.preproc, self.aug = train, pert, preproc, aug
        self.mean, self.std = (mean, std) if mean is not None else get_stats(preproc)

    def __len__(self):
        return len(self.df)

    def __getitem__(self, i):
        r = self.df.iloc[i]
        img = cv2.imread(str(config.PROC_DIR / r["path"]))
        h, w = img.shape[:2]
        if r["mask_path"]:
            mask = cv2.imread(str(config.PROC_DIR / r["mask_path"]), 0) > 127
        else:
            mask = np.zeros((h, w), bool)
        if self.pert:
            img = perturb(img, *self.pert)
        if self.train and self.aug in ("flip", "strong"):
            if np.random.rand() < 0.5:
                img, mask = img[:, ::-1], mask[:, ::-1]
            if np.random.rand() < 0.5:
                img, mask = img[::-1], mask[::-1]
            img, mask = np.ascontiguousarray(img), np.ascontiguousarray(mask)
        if self.train and self.aug == "strong":
            M = cv2.getRotationMatrix2D((w / 2, h / 2), np.random.uniform(-20, 20), 1.0)
            img = cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_LINEAR, borderValue=0)
            mask = cv2.warpAffine(mask.astype(np.uint8), M, (w, h), flags=cv2.INTER_NEAREST) > 0
            img = np.clip(img.astype(np.float32) * np.random.uniform(0.85, 1.15) + np.random.uniform(-15, 15), 0, 255).astype(np.uint8)
        img = apply_preproc(np.ascontiguousarray(img), self.preproc)
        mask = torch.from_numpy(np.ascontiguousarray(mask).astype(np.float32))[None]
        has_mask = torch.tensor(1.0 if r["cls"] in ("real", "manip") else 0.0)
        return bgr_to_tensor(img, self.mean, self.std), mask, self.cmap[r["cls"]], has_mask
