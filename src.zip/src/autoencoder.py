"""Course Exp 3 + 4: convolutional autoencoder on REAL images only.
 (a) reconstruction quality (MSE / PSNR) for real vs GAN vs manipulated images (visualised)
 (b) anomaly detection: reconstruction error as a 'fake score' -> AUC
 (c) Exp 3 comparison: classifier accuracy on ORIGINAL input (raw pixels) vs ENCODED input (latent code)

    python -m src.autoencoder --epochs 40 --seed 42
"""
import argparse, json
import numpy as np, cv2, pandas as pd, torch, torch.nn as nn, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score, accuracy_score
from . import config
from .utils import seed_all, get_device


class AE(nn.Module):
    def __init__(self, latent=128):
        super().__init__()
        def down(i, o): return [nn.Conv2d(i, o, 4, 2, 1), nn.BatchNorm2d(o), nn.ReLU(True)]
        def up(i, o): return [nn.ConvTranspose2d(i, o, 4, 2, 1), nn.BatchNorm2d(o), nn.ReLU(True)]
        self.enc = nn.Sequential(*down(3, 32), *down(32, 64), *down(64, 128), *down(128, 256), *down(256, 256))  # 128->4
        self.to_z = nn.Linear(256 * 16, latent)
        self.from_z = nn.Linear(latent, 256 * 16)
        self.dec = nn.Sequential(*up(256, 256), *up(256, 128), *up(128, 64), *up(64, 32),
                                 nn.ConvTranspose2d(32, 3, 4, 2, 1), nn.Sigmoid())                              # 4->128

    def encode(self, x):
        return self.to_z(self.enc(x).flatten(1))

    def forward(self, x):
        z = self.encode(x)
        return self.dec(self.from_z(z).view(-1, 256, 4, 4)), z


def load_split(split, cls):
    df = pd.read_csv(config.PROC_DIR / "meta.csv").fillna("")
    d = df[(df["split"] == split) & (df["cls"] == cls)]
    if d.empty:
        return None
    return np.stack([cv2.cvtColor(cv2.imread(str(config.PROC_DIR / p)), cv2.COLOR_BGR2RGB) for p in d["path"]])


def to_t(u8, dev):
    return torch.from_numpy(u8).permute(0, 3, 1, 2).float().div(255).to(dev)


@torch.no_grad()
def run_ae(model, u8, dev, bs=128):
    model.eval(); recs, zs = [], []
    for i in range(0, len(u8), bs):
        r, z = model(to_t(u8[i:i + bs], dev)); recs.append(r.cpu()); zs.append(z.cpu())
    rec = torch.cat(recs); z = torch.cat(zs).numpy()
    mse = ((rec - to_t(u8, "cpu")) ** 2).mean((1, 2, 3)).numpy()
    return rec, z, mse


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=40)
    ap.add_argument("--bs", type=int, default=64)
    ap.add_argument("--seed", type=int, default=config.SEED)
    a = ap.parse_args()
    seed_all(a.seed); dev = get_device()
    meta = pd.read_csv(config.PROC_DIR / "meta.csv")
    classes = [c for c in ["real", "gan", "manip"] + sorted(c for c in meta["cls"].unique() if str(c).startswith("ext_"))
               if c in set(meta["cls"])]
    tr, va = load_split("train", "real"), load_split("val", "real")

    model = AE().to(dev)
    opt = torch.optim.Adam(model.parameters(), 1e-3)
    gen = torch.Generator().manual_seed(a.seed)
    curve = []
    for ep in range(a.epochs):
        model.train(); perm = torch.randperm(len(tr), generator=gen).numpy(); tot = 0; nb = 0
        for i in range(0, len(tr) - a.bs + 1, a.bs):
            x = to_t(tr[perm[i:i + a.bs]], dev)
            rec, _ = model(x); loss = nn.functional.mse_loss(rec, x)
            opt.zero_grad(); loss.backward(); opt.step(); tot += loss.item(); nb += 1
        _, _, vm = run_ae(model, va, dev)
        curve.append({"epoch": ep + 1, "train_mse": tot / max(nb, 1), "val_mse": float(vm.mean())})
        if ep % 5 == 0 or ep == a.epochs - 1:
            print(curve[-1])

    # ---- (a)+(b) reconstruction error per class on the TEST split
    res = {"seed": a.seed, "curve": curve, "classes": {}, "auc_recon_error": {}}
    errs, recs, tests = {}, {}, {}
    for c in classes:
        u8 = load_split("test", c)
        if u8 is None:
            continue
        rec, _, mse = run_ae(model, u8, dev)
        tests[c], recs[c], errs[c] = u8, rec, mse
        res["classes"][c] = {"mse_mean": float(mse.mean()), "psnr_mean": float((10 * np.log10(1 / np.maximum(mse, 1e-10))).mean())}
    for c in errs:
        if c != "real":
            y = np.r_[np.zeros(len(errs["real"])), np.ones(len(errs[c]))]
            res["auc_recon_error"][f"real_vs_{c}"] = float(roc_auc_score(y, np.r_[errs["real"], errs[c]]))
    fakes = [c for c in errs if c != "real"]
    if fakes:
        y = np.r_[np.zeros(len(errs["real"])), np.ones(sum(len(errs[c]) for c in fakes))]
        res["auc_recon_error"]["real_vs_all_fake"] = float(roc_auc_score(y, np.concatenate([errs["real"]] + [errs[c] for c in fakes])))

    # ---- (c) classifier on original input vs encoded input (3 classes real/gan/manip)
    def feats(split):
        X_raw, X_z, y = [], [], []
        for k, c in enumerate(["real", "gan", "manip"]):
            u8 = load_split(split, c)
            if u8 is None:
                continue
            _, z, _ = run_ae(model, u8, dev)
            X_z.append(z); y += [k] * len(u8)
            X_raw.append(np.stack([cv2.resize(im, (32, 32), interpolation=cv2.INTER_AREA) for im in u8]).reshape(len(u8), -1) / 255.0)
        return np.concatenate(X_raw), np.concatenate(X_z), np.array(y)
    (Rtr, Ztr, ytr), (Rte, Zte, yte) = feats("train"), feats("test")
    cmp = {}
    for name, (A, B) in {"original_input_32x32_pixels": (Rtr, Rte), "encoded_input_latent128": (Ztr, Zte)}.items():
        sc = StandardScaler().fit(A)
        clf = LogisticRegression(max_iter=3000, random_state=a.seed).fit(sc.transform(A), ytr)
        cmp[name] = {"dim": int(A.shape[1]), "test_acc": float(accuracy_score(yte, clf.predict(sc.transform(B))))}
    res["classifier_original_vs_encoded"] = cmp
    json.dump(res, open(config.RESULTS_DIR / "autoencoder.json", "w"), indent=1)
    print(json.dumps({k: res[k] for k in ("classes", "auc_recon_error", "classifier_original_vs_encoded")}, indent=1))

    # ---- figures
    figs = config.RESULTS_DIR / "figs"; figs.mkdir(parents=True, exist_ok=True)
    show = [c for c in ["real", "gan", "manip"] if c in tests]; k = 5
    fig, ax = plt.subplots(2 * len(show), k, figsize=(2 * k, 4 * len(show)))
    for r, c in enumerate(show):
        for j in range(k):
            ax[2 * r, j].imshow(tests[c][j]); ax[2 * r + 1, j].imshow(recs[c][j].permute(1, 2, 0).numpy())
            ax[2 * r, j].axis("off"); ax[2 * r + 1, j].axis("off")
        ax[2 * r, 0].set_title(f"{c}: original (top) / reconstruction (bottom)", fontsize=8, loc="left")
    plt.tight_layout(); plt.savefig(figs / "ae_reconstruction.png", dpi=120); plt.close()
    plt.figure(figsize=(6, 3.5))
    for c in errs:
        plt.hist(errs[c], bins=30, alpha=.5, label=c)
    plt.xlabel("reconstruction MSE"); plt.ylabel("images"); plt.legend(); plt.title("Autoencoder reconstruction error")
    plt.tight_layout(); plt.savefig(figs / "ae_mse_hist.png", dpi=140); plt.close()
    plt.figure(figsize=(6, 3.5)); plt.plot([c["train_mse"] for c in curve], label="train"); plt.plot([c["val_mse"] for c in curve], label="val")
    plt.xlabel("epoch"); plt.ylabel("MSE"); plt.legend(); plt.title("Autoencoder convergence"); plt.grid(alpha=.3)
    plt.tight_layout(); plt.savefig(figs / "ae_curve.png", dpi=140); plt.close()


if __name__ == "__main__":
    main()
