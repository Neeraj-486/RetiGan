import os, random, sys, contextlib
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")      # needed for deterministic CUDA matmuls
os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")       # Apple GPU: unsupported ops fall back to CPU instead of crashing
import numpy as np
import cv2
from . import config

MEAN = np.array([0.485, 0.456, 0.406], np.float32)               # ImageNet defaults (only a fallback)
STD = np.array([0.229, 0.224, 0.225], np.float32)


# ------------------------------------------------------------------ reproducibility
def seed_all(s=config.SEED, deterministic=None):
    """Seed RNGs. Fast mode is default; set RETI_DETERMINISTIC=1 for stricter reproducibility."""
    import torch
    os.environ["PYTHONHASHSEED"] = str(s)
    random.seed(s); np.random.seed(s); torch.manual_seed(s); torch.cuda.manual_seed_all(s)
    if deterministic is None:
        deterministic = os.environ.get("RETI_DETERMINISTIC", "0") == "1"
    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        torch.use_deterministic_algorithms(True, warn_only=True)
    else:
        if torch.cuda.is_available():
            torch.backends.cudnn.benchmark = True


def seed_worker(_):
    """DataLoader worker init: each worker gets a seed derived from the loader's generator."""
    import torch
    s = torch.initial_seed() % (2 ** 32)
    np.random.seed(s); random.seed(s)


def make_loader(ds, bs, shuffle=False, seed=config.SEED, workers=None, drop_last=False):
    """DataLoader with a seeded generator + seeded workers => reproducible shuffling and augmentation."""
    import torch
    from torch.utils.data import DataLoader
    if workers is None:
        # macOS worker processes can cost more than they save for small 128px images.
        workers = int(os.environ.get("RETI_WORKERS", "0" if sys.platform == "darwin" else "2"))
    g = torch.Generator(); g.manual_seed(seed)
    kwargs = dict(batch_size=bs, shuffle=shuffle, num_workers=workers, generator=g, drop_last=drop_last)
    if workers > 0:
        kwargs.update(worker_init_fn=seed_worker, persistent_workers=True)
    if torch.cuda.is_available():
        kwargs["pin_memory"] = True
    return DataLoader(ds, **kwargs)


def get_device():
    """Prefer NVIDIA CUDA, then Apple Silicon MPS, then CPU."""
    import torch
    if torch.cuda.is_available():
        return torch.device("cuda")
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def autocast(device, enabled=True):
    """Mixed precision on CUDA only; a no-op on Apple MPS / CPU (keeps results simple and stable)."""
    import torch
    if getattr(device, "type", str(device)) == "cuda" and enabled:
        return torch.autocast(device_type="cuda")
    return contextlib.nullcontext()


def env_info():
    import platform
    info = {"python": platform.python_version(), "numpy": np.__version__, "opencv": cv2.__version__}
    for m in ("torch", "timm", "sklearn"):
        try:
            info[m] = __import__(m).__version__
        except Exception:
            pass
    try:
        import torch
        info["cuda"] = torch.version.cuda
        info["device"] = str(get_device())
        info["gpu"] = (torch.cuda.get_device_name(0) if torch.cuda.is_available() else ("Apple Silicon MPS" if get_device().type == "mps" else None))
    except Exception:
        pass
    return info


# ------------------------------------------------------------------ preprocessing
def crop_fundus(img):
    """Remove the black border around the circular retina."""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    ys, xs = np.where(gray > 15)
    if len(ys) == 0:
        return img
    return img[ys.min():ys.max() + 1, xs.min():xs.max() + 1]


_CM = {}
def circle_mask(size):
    if size not in _CM:
        m = np.zeros((size, size), np.uint8)
        cv2.circle(m, (size // 2, size // 2), size // 2 - 1, 255, -1)
        _CM[size] = m
    return _CM[size]


def apply_circle(img):
    return cv2.bitwise_and(img, img, mask=circle_mask(img.shape[0]))


def preprocess_bgr(img, size=config.IMG):
    """BASE preprocessing (saved to disk): crop border -> pad to square -> resize -> retina circle mask.
    Used for dataset building AND for dashboard uploads."""
    img = crop_fundus(img)
    h, w = img.shape[:2]
    s = max(h, w)
    canvas = np.zeros((s, s, 3), np.uint8)
    canvas[(s - h) // 2:(s - h) // 2 + h, (s - w) // 2:(s - w) // 2 + w] = img
    return apply_circle(cv2.resize(canvas, (size, size), interpolation=cv2.INTER_AREA))


def apply_preproc(img, mode):
    """Enhancement applied at load time (so it can be ablated without regenerating data).
    none | clahe (CLAHE on LAB lightness) | ben (Ben Graham: subtract local average colour)."""
    if mode == "none":
        return img
    if mode == "clahe":
        l, a, b = cv2.split(cv2.cvtColor(img, cv2.COLOR_BGR2LAB))
        l = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(l)
        out = cv2.cvtColor(cv2.merge([l, a, b]), cv2.COLOR_LAB2BGR)
    elif mode == "ben":
        radius = img.shape[0] / 2
        out = cv2.addWeighted(img, 4, cv2.GaussianBlur(img, (0, 0), radius / 30), -4, 128)
    else:
        raise ValueError(mode)
    return apply_circle(out)


def quality_ok(img):
    """Quality filter on the base image: reject nearly black/white or featureless (blurry/blank) photos."""
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    inside = circle_mask(g.shape[0]) > 0
    mean = float(g[inside].mean())
    sharp = float(cv2.Laplacian(g, cv2.CV_64F)[inside].var())
    return 25 < mean < 230 and sharp > 1.0


def perturb(img, kind, val):
    """Real-world degradations used for the robustness study."""
    size = img.shape[0]
    if kind == "jpeg":
        _, enc = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, int(val)])
        return cv2.imdecode(enc, 1)
    if kind == "resize":
        s = max(8, int(size * val))
        small = cv2.resize(img, (s, s), interpolation=cv2.INTER_AREA)
        return cv2.resize(small, (size, size), interpolation=cv2.INTER_LINEAR)
    if kind == "noise":
        return np.clip(img + np.random.normal(0, val, img.shape), 0, 255).astype(np.uint8)
    return img


def bgr_to_tensor(img, mean=None, std=None):
    """BGR uint8 HxWx3 -> normalized float tensor 3xHxW (dataset-specific mean/std)."""
    import torch
    mean = MEAN if mean is None else np.asarray(mean, np.float32)
    std = STD if std is None else np.asarray(std, np.float32)
    rgb = (cv2.cvtColor(img, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0 - mean) / std
    return torch.from_numpy(rgb.transpose(2, 0, 1).copy())
