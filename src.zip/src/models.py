"""RetiForGAN: two-stream detector with an optional manipulation-localization head.

 RGB stream      : backbone -> deepest feature map -> global pool
                   backbones: any timm CNN (ResNet-50, EfficientNet-B0 ...), 'resnet_small' (our own ResNet with
                   residual blocks, from scratch) or 'plaincnn' (VGG-style CNN, from scratch)
 Frequency stream: [log-magnitude FFT spectrum, high-pass noise residual] -> small CNN -> 128-d
 Classifier      : concat(pooled RGB, freq) -> dropout -> FC
 Mask head       : UNet-style decoder over the backbone pyramid -> per-pixel 'edited' logits
Flags use_freq / use_mask switch parts off, which gives the baselines and ablations.
"""
import contextlib
import torch, torch.nn as nn, torch.nn.functional as F, timm


class _FeatInfo:                       # mimics timm's feature_info for our own backbones
    def __init__(self, ch): self.ch = ch
    def channels(self): return self.ch


class PlainCNN(nn.Module):
    """VGG-style stack: [conv-BN-ReLU x2 -> maxpool] x5  (strides 2..32). No skip connections."""
    def __init__(self, widths=(32, 64, 128, 256, 256)):
        super().__init__()
        stages, prev = [], 3
        for w in widths:
            stages.append(nn.Sequential(
                nn.Conv2d(prev, w, 3, padding=1, bias=False), nn.BatchNorm2d(w), nn.ReLU(True),
                nn.Conv2d(w, w, 3, padding=1, bias=False), nn.BatchNorm2d(w), nn.ReLU(True), nn.MaxPool2d(2)))
            prev = w
        self.stages = nn.ModuleList(stages)
        self.feature_info = _FeatInfo(list(widths))

    def forward(self, x):
        feats = []
        for s in self.stages:
            x = s(x); feats.append(x)
        return feats


class BasicBlock(nn.Module):
    """Residual block: y = ReLU( F(x) + shortcut(x) )."""
    def __init__(self, i, o, stride):
        super().__init__()
        self.c1 = nn.Conv2d(i, o, 3, stride, 1, bias=False); self.b1 = nn.BatchNorm2d(o)
        self.c2 = nn.Conv2d(o, o, 3, 1, 1, bias=False); self.b2 = nn.BatchNorm2d(o)
        self.short = nn.Identity() if (stride == 1 and i == o) else nn.Sequential(
            nn.Conv2d(i, o, 1, stride, bias=False), nn.BatchNorm2d(o))

    def forward(self, x):
        y = self.b2(self.c2(F.relu(self.b1(self.c1(x)))))
        return F.relu(y + self.short(x))


class SmallResNet(nn.Module):
    """ResNet-18-style network written from scratch (course Exp 5): stem + 4 stages x 2 residual blocks."""
    def __init__(self, widths=(64, 128, 256, 512)):
        super().__init__()
        self.stem = nn.Sequential(nn.Conv2d(3, 32, 3, 2, 1, bias=False), nn.BatchNorm2d(32), nn.ReLU(True))
        layers, prev = [], 32
        for w in widths:
            layers.append(nn.Sequential(BasicBlock(prev, w, 2), BasicBlock(w, w, 1))); prev = w
        self.layers = nn.ModuleList(layers)
        self.feature_info = _FeatInfo([32] + list(widths))

    def forward(self, x):
        x = self.stem(x); feats = [x]
        for l in self.layers:
            x = l(x); feats.append(x)
        return feats


def make_backbone(arch, pretrained):
    if arch == "plaincnn":
        return PlainCNN()
    if arch == "resnet_small":
        return SmallResNet()
    return timm.create_model(arch, pretrained=pretrained, features_only=True)


class ConvBlock(nn.Module):
    def __init__(self, i, o):
        super().__init__()
        self.b = nn.Sequential(
            nn.Conv2d(i, o, 3, padding=1, bias=False), nn.BatchNorm2d(o), nn.ReLU(True),
            nn.Conv2d(o, o, 3, padding=1, bias=False), nn.BatchNorm2d(o), nn.ReLU(True))

    def forward(self, x):
        return self.b(x)


def freq_input(x):
    """x: normalized RGB batch -> 2-channel frequency-domain input (computed on the fly, in fp32).
    On Apple MPS the FFT is done on the CPU (not reliably supported on the GPU), then moved back."""
    dev = x.device
    g = x.float().mean(1, keepdim=True)
    if dev.type == "mps":
        g = g.cpu()
    ctx = torch.autocast(device_type="cuda", enabled=False) if dev.type == "cuda" else contextlib.nullcontext()
    with ctx:
        spec = torch.log1p(torch.abs(torch.fft.fftshift(torch.fft.fft2(g), dim=(-2, -1))))
        spec = (spec - spec.mean((1, 2, 3), keepdim=True)) / (spec.std((1, 2, 3), keepdim=True) + 1e-6)
        res = g - F.avg_pool2d(g, 5, 1, 2)                       # high-pass residual (noise fingerprint)
        res = (res - res.mean((1, 2, 3), keepdim=True)) / (res.std((1, 2, 3), keepdim=True) + 1e-6)
    return torch.cat([spec, res], 1).to(dev)


class FreqStream(nn.Module):
    def __init__(self, out=128):
        super().__init__()
        chs, layers = [2, 32, 64, 128, out], []
        for i in range(4):
            layers += [nn.Conv2d(chs[i], chs[i + 1], 3, 2, 1, bias=False), nn.BatchNorm2d(chs[i + 1]), nn.ReLU(True)]
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x).mean((2, 3))


class Decoder(nn.Module):
    def __init__(self, chs, mid=64):
        super().__init__()
        self.blocks = nn.ModuleList()
        prev = chs[-1]
        for c in reversed(chs[:-1]):
            self.blocks.append(ConvBlock(prev + c, mid)); prev = mid
        self.head = nn.Conv2d(prev, 1, 1)

    def forward(self, feats, size):
        x = feats[-1]
        for blk, skip in zip(self.blocks, reversed(feats[:-1])):
            x = F.interpolate(x, size=skip.shape[2:], mode="bilinear", align_corners=False)
            x = blk(torch.cat([x, skip], 1))
        return F.interpolate(self.head(x), size=size, mode="bilinear", align_corners=False)  # logits


class RetiForGAN(nn.Module):
    def __init__(self, arch="resnet50", num_classes=3, use_freq=True, use_mask=True, pretrained=True, dropout=0.3):
        super().__init__()
        self.cfg = dict(arch=arch, num_classes=num_classes, use_freq=use_freq, use_mask=use_mask, dropout=dropout)
        self.use_freq, self.use_mask = use_freq, use_mask
        self.backbone = make_backbone(arch, pretrained)
        chs = self.backbone.feature_info.channels()
        d = chs[-1]
        if use_freq:
            self.freq = FreqStream(128); d += 128
        self.drop = nn.Dropout(dropout)
        self.fc = nn.Linear(d, num_classes)
        if use_mask:
            self.decoder = Decoder(chs)

    def forward(self, x):
        feats = self.backbone(x)
        f = feats[-1]
        v = f.mean((2, 3))
        if self.use_freq:
            v = torch.cat([v, self.freq(freq_input(x))], 1)
        out = {"logits": self.fc(self.drop(v)), "feat": f}
        if self.use_mask:
            out["mask"] = self.decoder(feats, x.shape[2:])
        return out
