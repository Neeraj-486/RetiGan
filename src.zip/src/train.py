"""Train one model.
   python -m src.train --name full_s42 --arch resnet50 --freq --mask --epochs 10 --seed 42
Course-relevant switches: --epochs (convergence), --aug/--dropout/--wd/--patience/--select (regularization),
--freeze/--no-pretrained (fine-tuning study), --preproc (none|clahe|ben)."""
import argparse, json, time
import numpy as np, torch, torch.nn.functional as F
from . import config
from .dataset import FundusDS, get_stats
from .models import RetiForGAN
from .metrics import infer, cls_metrics, val_loss
from .utils import seed_all, get_device, make_loader, env_info, autocast

SCRATCH_ARCHS = ("plaincnn", "resnet_small")


def mask_loss(logits, target, w):
    """BCE + Dice, averaged over samples that have a valid mask (real: empty mask, manip: true mask)."""
    if w.sum() == 0:
        return logits.sum() * 0
    bce = F.binary_cross_entropy_with_logits(logits, target, reduction="none").mean((1, 2, 3))
    p = torch.sigmoid(logits)
    inter = (p * target).sum((1, 2, 3))
    dice = 1 - (2 * inter + 1) / (p.sum((1, 2, 3)) + target.sum((1, 2, 3)) + 1)
    return ((bce + dice) * w).sum() / w.sum()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--arch", default="resnet50")
    ap.add_argument("--classes", default="real,gan,manip")
    ap.add_argument("--freq", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--mask", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--pretrained", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--freeze", action="store_true", help="freeze backbone (train heads only)")
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-4)
    ap.add_argument("--wd", type=float, default=1e-4)
    ap.add_argument("--dropout", type=float, default=0.3)
    ap.add_argument("--aug", default="flip", choices=["none", "flip", "strong"])
    ap.add_argument("--patience", type=int, default=0, help="early stopping patience in epochs (0 = off)")
    ap.add_argument("--select", default="best", choices=["best", "last"], help="checkpoint = best-val or last epoch")
    ap.add_argument("--preproc", default=config.DEFAULT_PREPROC, choices=config.PREPROC_MODES)
    ap.add_argument("--lambda_mask", type=float, default=1.0)
    ap.add_argument("--seed", type=int, default=config.SEED)
    a = ap.parse_args()

    seed_all(a.seed); dev = get_device()
    classes = a.classes.split(",")
    mean, std = get_stats(a.preproc)
    tr_ds = FundusDS("train", classes, True, None, a.preproc, a.aug, mean, std)
    va_ds = FundusDS("val", classes, False, None, a.preproc, "none", mean, std)
    tr = make_loader(tr_ds, a.bs, True, a.seed, drop_last=True)
    model = RetiForGAN(a.arch, len(classes), a.freq, a.mask, a.pretrained, a.dropout).to(dev)
    if a.freeze:
        for p in model.backbone.parameters():
            p.requires_grad = False
    scratch = a.arch in SCRATCH_ARCHS or not a.pretrained
    bb = [p for p in model.backbone.parameters() if p.requires_grad]
    ids = {id(p) for p in model.backbone.parameters()}
    rest = [p for p in model.parameters() if id(p) not in ids]
    groups = ([{"params": bb, "lr": a.lr * (5 if scratch else 1)}] if bb else []) + [{"params": rest, "lr": a.lr * 5}]
    opt = torch.optim.AdamW(groups, weight_decay=a.wd)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, a.epochs * len(tr))
    scaler = torch.amp.GradScaler(enabled=dev.type == "cuda")
    run_dir = config.RUNS_DIR / a.name; run_dir.mkdir(parents=True, exist_ok=True)
    json.dump(env_info(), open(run_dir / "env.json", "w"), indent=1)

    def save(ep):
        torch.save({"state": model.state_dict(), "cfg": model.cfg, "classes": classes, "preproc": a.preproc,
                    "mean": mean, "std": std, "seed": a.seed, "epoch": ep, "args": vars(a)}, run_dir / "best.pt")

    best, bad, hist = -1.0, 0, []
    print(f"[{a.name}] arch={a.arch} freq={a.freq} mask={a.mask} classes={classes} seed={a.seed} "
          f"preproc={a.preproc} aug={a.aug} train={len(tr_ds)} val={len(va_ds)}")
    for ep in range(a.epochs):
        t0 = time.time()
        model.train()
        if a.freeze:
            model.backbone.eval()
        tot, correct, n = 0.0, 0, 0
        for x, m, y, w in tr:
            x, m, y, w = x.to(dev), m.to(dev), y.to(dev), w.to(dev)
            with autocast(dev):
                out = model(x)
            loss = F.cross_entropy(out["logits"].float(), y)
            if a.mask:
                loss = loss + a.lambda_mask * mask_loss(out["mask"].float(), m, w)
            opt.zero_grad(); scaler.scale(loss).backward(); scaler.step(opt); scaler.update(); sched.step()
            tot += loss.item(); correct += (out["logits"].argmax(1) == y).sum().item(); n += len(y)
        P, Y, _, _ = infer(model, va_ds, dev)
        met, _ = cls_metrics(P, Y, classes)
        hist.append({"epoch": ep + 1, "train_loss": round(tot / len(tr), 4), "train_acc": round(correct / n, 4),
                     "val_loss": round(val_loss(P, Y), 4), **{f"val_{k}": v for k, v in met.items()}, "sec": round(time.time() - t0, 1)})
        print(hist[-1])
        if met["f1"] > best:
            best, bad = met["f1"], 0
            if a.select == "best":
                save(ep + 1)
        else:
            bad += 1
        if a.select == "last":
            save(ep + 1)
        if a.patience and bad >= a.patience:
            print(f"early stopping at epoch {ep + 1}"); break
    json.dump(hist, open(run_dir / "history.json", "w"), indent=1)
    print("saved", run_dir / "best.pt", "| best val f1", best)


if __name__ == "__main__":
    main()
