import numpy as np
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, confusion_matrix


def infer(model, ds, device, bs=64):
    """Returns probs (N,C), labels (N,), predicted mask probs (N,H,W) or None, GT masks (N,H,W)."""
    import torch
    from .utils import make_loader, autocast
    model.eval(); P, Y, M, G = [], [], [], []
    with torch.no_grad():
        for x, m, y, _ in make_loader(ds, bs, shuffle=False, seed=0):
            with autocast(device):
                out = model(x.to(device))
            P.append(torch.softmax(out["logits"].float(), 1).cpu().numpy()); Y.append(y.numpy())
            G.append(m[:, 0].numpy().astype(np.uint8))
            if "mask" in out:
                M.append(torch.sigmoid(out["mask"].float()).cpu().numpy()[:, 0])
    return np.concatenate(P), np.concatenate(Y), (np.concatenate(M) if M else None), np.concatenate(G)


def cls_metrics(P, Y, classes):
    nc = P.shape[1]; pred = P.argmax(1)
    out = dict(acc=accuracy_score(Y, pred), f1=f1_score(Y, pred, average="macro"))
    try:
        out["auc"] = roc_auc_score(Y, P[:, 1]) if nc == 2 else roc_auc_score(Y, P, multi_class="ovr")
        if nc > 2:
            out["auc_real_vs_fake"] = roc_auc_score(Y != 0, 1 - P[:, 0])
    except ValueError:
        pass
    return {k: round(float(v), 4) for k, v in out.items()}, confusion_matrix(Y, pred, labels=range(nc)).tolist()


def val_loss(P, Y):
    return float(-np.log(np.clip(P[np.arange(len(Y)), Y], 1e-8, 1)).mean())


def fake_scores(P):
    """Score that an image is fake (any kind) = 1 - P(real). Class 0 is always 'real'."""
    return 1 - P[:, 0]


def threshold_table(score, is_fake, ths=None):
    """Confusion counts and rates for a sweep of decision thresholds on the fake score."""
    ths = np.linspace(0.05, 0.95, 19) if ths is None else ths
    is_fake = np.asarray(is_fake, bool); rows = []
    for t in ths:
        pred = score >= t
        tp = int((pred & is_fake).sum()); fp = int((pred & ~is_fake).sum())
        fn = int((~pred & is_fake).sum()); tn = int((~pred & ~is_fake).sum())
        tpr = tp / max(tp + fn, 1); fpr = fp / max(fp + tn, 1); prec = tp / max(tp + fp, 1)
        f1 = 2 * prec * tpr / max(prec + tpr, 1e-9)
        rows.append(dict(threshold=round(float(t), 2), tpr=round(tpr, 4), fpr=round(fpr, 4),
                         precision=round(prec, 4), f1=round(f1, 4), tp=tp, fp=fp, fn=fn, tn=tn))
    return rows


def dice_iou(pred, gt, eps=1e-6):
    inter = (pred & gt).sum((1, 2)); p = pred.sum((1, 2)); g = gt.sum((1, 2))
    return 2 * inter / (p + g + eps), inter / (p + g - inter + eps)


def loc_metrics(M, G, df, classes, P):
    """Localization quality on manipulated test images + per-manipulation-type breakdown."""
    if "manip" not in classes:
        return None, {}
    mi = classes.index("manip")
    sel = np.where(df["cls"].values == "manip")[0]
    pred = P.argmax(1)
    per_kind, dices, ious = {}, None, None
    if M is not None:
        dices, ious = dice_iou(M[sel] > 0.5, G[sel] > 0)
    for k in sorted(set(df["kind"].values[sel])):
        idx = np.where(df["kind"].values[sel] == k)[0]
        e = {"detect_recall": round(float((pred[sel][idx] == mi).mean()), 4)}
        if dices is not None:
            e["dice"] = round(float(dices[idx].mean()), 4); e["iou"] = round(float(ious[idx].mean()), 4)
        per_kind[k] = e
    loc = None
    if dices is not None:
        loc = {"dice": round(float(dices.mean()), 4), "iou": round(float(ious.mean()), 4)}
    return loc, per_kind
