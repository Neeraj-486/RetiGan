# Viva preparation: be able to answer these about YOUR project
1. Why is detecting fake fundus images important? (data poisoning, fraud, research integrity)
2. Why did you split by source image BEFORE creating manipulations? (no leakage of the same eye across train/test)
3. Why save everything as PNG? (JPEG vs PNG format would be a shortcut the model could learn)
4. Why a circle mask, CLAHE, Ben Graham? What did the ablation show?
5. Why fixed seeds and 3 seeds? What does mean ± std tell you? What does deterministic mode do?
6. What is a residual block and why does a skip connection help gradients flow?
7. Why did the pretrained ResNet beat the scratch ones? What happened with a frozen backbone? (CO4)
8. Dropout vs weight decay vs augmentation vs early stopping: what does each do, which helped most? (CO3)
9. What is overfitting and how does your train-validation gap show it?
10. What happens to loss/accuracy with more epochs? When do you stop? (Exp 1)
11. What does moving the threshold do to false positives and false negatives? Which would you pick? (Exp 2)
12. How does the autoencoder detect fakes? Why can reconstruction error work (or fail)? Original vs encoded input result? (Exp 3-4)
13. Why does the frequency stream help? What do GAN artifacts look like in the Fourier spectrum?
14. How does Grad-CAM work? What did it highlight?
15. How does the mask head localize edits? Why BCE + Dice? What do Dice and IoU measure?
16. Explain the GAN objective (generator vs discriminator). What is mode collapse? Where did you see limitations? (CO5)
17. Why train the GAN on the TRAIN split only?
18. What is the difference between StyleGAN and your DCGAN?
19. Why do detectors fail on unseen generators? What did your cross-generator test show?
20. Limitations of your project, honestly. (synthetic edits, weak GAN, image-level split, 128px, not clinical)
