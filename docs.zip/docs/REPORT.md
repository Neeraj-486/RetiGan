# RetiForGAN: Detecting AI-Generated and Manipulated Retinal Fundus Images
Deep Learning Laboratory (ADA23CL301) - report skeleton. Replace every [FILL] with your numbers from `results/`.
Figures are in `results/figs/`, tables in `results/*.csv` (all mean ± std over 3 seeds unless stated).

## 1. Introduction  (CO1)
- Problem: generated or edited fundus images can poison datasets and enable fraud. [1 paragraph]
- Objectives: detect (real / GAN / manipulated), localize edits, stay robust, explain predictions.
- Contributions: dataset builder with masks; two-stream detector with localization head; study of epochs, regularization, fine-tuning, preprocessing, robustness, cross-generator generalization.
- Deep learning components used and challenges met (overfitting, small data, domain shift, instability of GAN training).

## 2. Dataset and preprocessing
- APTOS 2019, [FILL] images used, split 70/15/15 by source image (no leakage). Seeds: data 42, models 42/43/44.
- Preprocessing: crop, circle mask, quality filter ([FILL] dropped), CLAHE / Ben Graham, dataset mean/std. (`data_report.json`)
- Fake data: DCGAN (Section 6), 5 manipulation types with masks. PNG only. Figure: `gan_samples.png`, dataset page of dashboard.

## 3. Experiment 1: Epochs and convergence (CO1)
Figures: `convergence_epochs.png`, `convergence_arch.png`. Discuss: speed of convergence for 5/10/20 epochs,
where validation loss stops improving, why a deeper pretrained net converges faster than a scratch CNN.

## 4. Experiment 2: Classification and thresholds (CO2)
Figures: `roc.png`, `threshold_sweep.png`, `table_main.csv`. Discuss: which threshold you would deploy and why;
which confusions dominate (confusion matrices in the dashboard); cost of false alarms vs missed fakes.

## 5. Experiments 3-4: Autoencoder (CO2)
`autoencoder.json`, `ae_reconstruction.png`, `ae_mse_hist.png`. Discuss: do fakes reconstruct worse; AUC of reconstruction error;
accuracy with original input (32x32 pixels) vs encoded input (128-d latent) and what this says about representations.

## 6. Experiment 9: GAN and its limitations (CO5)
`gan_losses.png`, `gan_samples.png`, `gan_stats.json`. Discuss: adversarial training, instability, mode collapse (diversity ratio [FILL]),
visual artifacts, why a detector trained on one generator may not transfer.
**StyleGAN (Exp 9 Part A):** mapping network, style modulation/demodulation, per-layer noise, style mixing, truncation trick, ADA (`stylegan/STYLEGAN.md` table).
**StyleGAN (Part B):** fine-tuning setup (FFHQ-256 -> fundus, [FILL] kimg), sample images, detector AUC on StyleGAN fakes vs truncation psi (`stylegan_truncation.png`, `table_external_generators.csv`), what it says about generalization.

## 7. Experiments 5-6: Network architectures (CO2, CO3)
Plain CNN vs ResNet from scratch vs pretrained ResNet-50 vs EfficientNet-B0 (`table_main.csv`).
Explain residual connections and why they ease optimization.

## 8. Experiment 7: VGG-16 features and clustering (CO4)
`clustering.json`, `vgg16_tsne.png`. ARI [FILL], NMI [FILL], purity [FILL]. Discuss: do ImageNet features separate real from fake without training?

## 9. Experiment 8: Fine-tuning (CO4)
`table_finetuning.csv`: frozen backbone vs random init vs full fine-tuning. Discuss why pretrained features transfer to fundus images.

## 10. Regularization (CO3)
`table_regularization.csv`, `regularization.png`: none vs dropout vs weight decay vs augmentation vs early stopping vs all.
Discuss the train-validation gap for each technique and what each one does mathematically.

## 11. RetiForGAN: ablations, robustness, generalization, localization
- Ablation: frequency stream, mask head (`table_main.csv`); preprocessing none/CLAHE/Ben (`table_preprocessing.csv`).
- Robustness: JPEG/resize/noise (`robustness.png`).
- Cross-generator: `table_cross_generator.csv` (and external generator if added).
- Localization: Dice/IoU per edit type (`table_per_manipulation.csv`), Grad-CAM + predicted masks (`qualitative_*.png`).

## 12. Dashboard
Screenshots: Live detector, Threshold analysis, Results, Dataset. Describe how a clinician or data curator would use it.

## 13. Limitations and future work
Copy the limitations list from README.md. Future: StyleGAN2-ADA / diffusion fakes, multi-dataset training, patient-level splits, DR-grading contamination study.

## 14. Reproducibility
Seeds, deterministic mode, library versions (`runs/*/env.json`), exact commands from README.md.

## References
Goodfellow, Bengio, Courville - Deep Learning (MIT Press, 2016). Geron - Hands-On ML (2nd ed.). Add: DCGAN (Radford et al.), ResNet (He et al.),
VGG (Simonyan & Zisserman), Grad-CAM (Selvaraju et al.), APTOS 2019 dataset.
