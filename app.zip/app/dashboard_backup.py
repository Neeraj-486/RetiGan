"""RetiForGAN dashboard.   streamlit run app/dashboard.py
Pages: Live detector | Batch scan | Threshold analysis | Results | Dataset"""
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import cv2, numpy as np, pandas as pd, streamlit as st, torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, roc_auc_score
from src import config
from src.models import RetiForGAN
from src.utils import preprocess_bgr, perturb, apply_preproc, bgr_to_tensor
from src.explain import analyze, overlay, spectrum_image
from src.make_report import load_results, aggregate, MAIN_ORDER
from src.metrics import fake_scores, threshold_table

st.set_page_config(page_title="RetiForGAN", page_icon="👁️", layout="wide")

# ---------------- visual system ----------------
st.markdown("""
<style>
:root {
  --rf-bg: #10151b;
  --rf-panel: #171e26;
  --rf-panel-soft: #1d2630;
  --rf-border: #2b3743;
  --rf-text: #e8edf2;
  --rf-muted: #9aa8b5;
  --rf-accent: #78aaa5;
}
.stApp { background: var(--rf-bg); color: var(--rf-text); }
[data-testid="stHeader"] { background: rgba(16,21,27,.92); }
[data-testid="stSidebar"] { background: #141a21; border-right: 1px solid var(--rf-border); }
.block-container { max-width: 1500px; padding-top: 2rem; padding-bottom: 3rem; }
h1, h2, h3 { letter-spacing: -0.025em; }
h1 { font-weight: 650; }
[data-testid="stMetric"] {
  background: var(--rf-panel); border: 1px solid var(--rf-border);
  border-radius: 12px; padding: 14px 16px;
}
[data-testid="stMetricLabel"] { color: var(--rf-muted); }
[data-testid="stMetricValue"] { color: var(--rf-text); }
[data-testid="stAlert"] { border-radius: 10px; }
div[data-testid="stFileUploader"] section {
  background: var(--rf-panel); border: 1px dashed #536473; border-radius: 12px;
}
div[data-testid="stSelectbox"] > label,
div[data-testid="stSlider"] > label,
div[data-testid="stNumberInput"] > label { color: var(--rf-muted); }
.stButton button, .stDownloadButton button {
  border-radius: 9px; border: 1px solid #496b6a; background: #233b3b;
}
.stButton button:hover, .stDownloadButton button:hover {
  border-color: var(--rf-accent); color: #fff;
}
hr { border-color: var(--rf-border); }
[data-testid="stDataFrame"] { border: 1px solid var(--rf-border); border-radius: 10px; overflow: hidden; }
.rf-eyebrow { color: var(--rf-accent); text-transform: uppercase; letter-spacing: .13em; font-size: .72rem; font-weight: 700; }
.rf-subtitle { color: var(--rf-muted); font-size: .96rem; margin-top: -.45rem; }
.rf-card { background: var(--rf-panel); border: 1px solid var(--rf-border); border-radius: 14px; padding: 18px; }
.rf-note { color: var(--rf-muted); font-size: .85rem; }
</style>
""", unsafe_allow_html=True)
FRIENDLY = {"real": "Authentic retinal image", "gan": "AI-generated (GAN)", "manip": "Manipulated / edited"}
FIGS = config.RESULTS_DIR / "figs"


def friendly(c):
    return FRIENDLY.get(c, f"AI-generated ({c.replace('ext_', '')})" if c.startswith("ext_") else c)


@st.cache_resource
def load_model(path):
    ck = torch.load(path, map_location="cpu", weights_only=False)          # our own checkpoints
    c = ck["cfg"]
    m = RetiForGAN(c["arch"], c["num_classes"], c["use_freq"], c["use_mask"], pretrained=False, dropout=c.get("dropout", 0.3))
    m.load_state_dict(ck["state"]); m.eval()
    return m, {"classes": ck["classes"], "cfg": c, "preproc": ck.get("preproc", "none"), "mean": ck.get("mean"), "std": ck.get("std")}


def decode(f):
    return cv2.imdecode(np.frombuffer(f.getvalue(), np.uint8), cv2.IMREAD_COLOR)


def prepare(img, info, jpeg_q=100, noise=0):
    """Same pipeline as training: base preprocessing -> optional degradation -> model preprocessing -> tensor."""
    base = preprocess_bgr(img, config.IMG)
    if jpeg_q < 100:
        base = perturb(base, "jpeg", jpeg_q)
    if noise > 0:
        base = perturb(base, "noise", noise)
    x = bgr_to_tensor(apply_preproc(base, info["preproc"]), info["mean"], info["std"])[None]
    return base, x


def show_fig(name, caption=None):
    p = FIGS / name
    if p.exists():
        st.image(str(p), caption=caption, use_container_width=True)


def show_csv(name, title=None):
    p = config.RESULTS_DIR / name
    if p.exists():
        if title:
            st.markdown(f"**{title}**")
        st.dataframe(pd.read_csv(p), use_container_width=True)


# ---------------- sidebar ----------------
st.sidebar.markdown("## 👁️ RetiForGAN")
st.sidebar.caption("Retinal image authenticity research")
st.sidebar.markdown("---")
page = st.sidebar.radio(
    "WORKSPACE",
    ["Live detector", "Batch scan", "Threshold analysis", "Results", "Dataset"],
    label_visibility="visible",
)
st.sidebar.markdown("---")
st.sidebar.caption("RESEARCH PROTOTYPE")
st.sidebar.caption("Not a clinical or forensic decision tool.")
model = info = None
if page in ("Live detector", "Batch scan"):
    ckpts = sorted(config.RUNS_DIR.glob("*/best.pt"))
    ckpts = [p for p in ckpts if p.parent.name != "dcgan"]
    if not ckpts:
        st.sidebar.warning("No trained checkpoints in runs/ yet.")
    else:
        names = [p.parent.name for p in ckpts]
        # Prefer the latest named project checkpoint; fall back to the earlier full run.
        preferred = next((i for i, n in enumerate(names) if n == "retiforgan_final"), None)
        if preferred is None:
            preferred = next((i for i, n in enumerate(names) if n.startswith("full_s")), 0)
        sel = st.sidebar.selectbox("Active checkpoint", names, index=preferred)
        model, info = load_model(str(config.RUNS_DIR / sel / "best.pt"))
        c = info["cfg"]
        st.sidebar.caption(f"{c['arch']} | frequency stream: {c['use_freq']} | localization head: {c['use_mask']} | preprocessing: {info['preproc']}")

# ---------------- live detector ----------------
if page == "Live detector":
    st.markdown('<div class="rf-eyebrow">RetiForGAN / Analysis workspace</div>', unsafe_allow_html=True)
    st.title("Fundus authenticity analysis")
    st.markdown('<div class="rf-subtitle">Screen a retinal fundus image for synthetic or manipulated content, then inspect the model evidence.</div>', unsafe_allow_html=True)
    st.write("")

    if model is None:
        st.warning("No trained checkpoint is available. Train a model and place its best.pt file under runs/<experiment>/best.pt.")
        st.stop()

    classes = info["classes"]
    with st.container(border=True):
        left, right = st.columns([0.95, 1.45], gap="large")
        with left:
            st.markdown("#### 01 · Select image")
            up = st.file_uploader("Upload a fundus image", type=["png", "jpg", "jpeg"])
            sample, meta_p = None, config.PROC_DIR / "meta.csv"
            if meta_p.exists():
                t = pd.read_csv(meta_p).fillna("")
                t = t[t["split"] == "test"]
                if not t.empty:
                    st.caption("Or load an existing sample")
                    sample_classes = sorted(t["cls"].unique())
                    sc = st.selectbox("Sample class", sample_classes)
                    class_rows = t[t["cls"] == sc]
                    si = st.number_input("Sample index", 0, max(0, len(class_rows) - 1), 0)
                    if not class_rows.empty:
                        sample = class_rows.iloc[int(si)]

            with st.expander("Stress-test settings", expanded=False):
                st.caption("Apply controlled degradation to explore sensitivity. This is not a validated robustness test by itself.")
                jq = st.slider("JPEG quality", 20, 100, 100, help="100 applies no JPEG compression.")
                nz = st.slider("Gaussian noise (sigma)", 0, 15, 0, help="0 applies no added noise.")
        img = decode(up) if up is not None else (
            cv2.imread(str(config.PROC_DIR / sample["path"])) if sample is not None else None
        )
        if up is None and sample is not None:
            st.caption(f"Selected sample · label: `{sample['cls']}`" +
                       (f" · manipulation: `{sample['kind']}`" if sample.get("kind", "") else ""))
        if img is None:
            st.info("Upload an image or select a sample to begin analysis.")
            st.stop()

        base, x = prepare(img, info, jq, nz)
        with torch.no_grad():
            r = analyze(model, x)
        probs = pd.Series(r["probs"], index=[friendly(c) for c in classes])
        verdict = classes[r["pred"]]
        fake_idx = [i for i, c in enumerate(classes) if c != "real"]
        p_fake = float(sum(r["probs"][i] for i in fake_idx))
        confidence = float(max(r["probs"]))

        with right:
            st.markdown("#### 02 · Model output")
            k1, k2, k3 = st.columns(3)
            k1.metric("Predicted class", friendly(verdict))
            k2.metric("Top-class score", f"{100 * confidence:.1f}%")
            k3.metric("P(any fake)", f"{100 * p_fake:.1f}%")
            st.caption("Scores are model outputs, not calibrated probabilities unless calibration has been independently validated.")
            if verdict == "real":
                st.info("The model classified this image as authentic. This does not prove the image is genuine.")
            else:
                st.warning("The model detected synthetic or manipulation-related patterns. Review the image and explanation.")
            st.markdown("**Class score distribution**")
            st.bar_chart(probs, color="#78aaa5", horizontal=True)

        st.markdown("---")
        st.markdown("#### 03 · Image and explanation")
        st.caption("Explanatory visualizations indicate model behaviour; they are not ground-truth evidence of editing.")
        original_col, detail_col = st.columns([1.15, 1], gap="large")
        with original_col:
            st.image(cv2.cvtColor(base, cv2.COLOR_BGR2RGB), caption="Model input after preprocessing", use_container_width=True)
        with detail_col:
            if r["mask"] is not None:
                st.image(overlay(base, r["mask"]), caption="Predicted localization map", use_container_width=True)
            else:
                st.info("This checkpoint has no localization head. Select a model configured with localization to view this output.")
        with st.expander("Additional model explanations", expanded=False):
            exp1, exp2 = st.columns(2, gap="large")
            with exp1:
                st.image(overlay(base, r["cam"]), caption="Grad-CAM · regions influencing the classifier", use_container_width=True)
            with exp2:
                st.image(spectrum_image(base), caption="Fourier magnitude spectrum", use_container_width=True)

    st.caption("RetiForGAN is a research prototype for AI-generated and manipulated retinal image analysis. It is not a clinical or forensic decision tool.")

# ---------------- batch scan ----------------
elif page == "Batch scan":
    st.title("Batch scan")
    if model is None:
        st.stop()
    classes = info["classes"]
    files = st.file_uploader("Upload several images", type=["png", "jpg", "jpeg"], accept_multiple_files=True)
    if files:
        rows, bar = [], st.progress(0.0)
        for i, f in enumerate(files):
            img = decode(f)
            if img is None:
                continue
            with torch.no_grad():
                p = torch.softmax(model(prepare(img, info)[1])["logits"], 1)[0].numpy()
            rows.append({"file": f.name, "verdict": friendly(classes[int(p.argmax())]),
                         **{f"P({c})": round(float(v), 3) for c, v in zip(classes, p)},
                         "P(any fake)": round(float(1 - p[classes.index("real")]), 3)})
            bar.progress((i + 1) / len(files))
        df = pd.DataFrame(rows)
        st.dataframe(df, use_container_width=True)
        st.download_button("Download CSV", df.to_csv(index=False), "retiforgan_scan.csv", "text/csv")
        st.bar_chart(df["verdict"].value_counts())

# ---------------- threshold analysis ----------------
elif page == "Threshold analysis":
    st.title("Threshold analysis")
    st.caption("Move the decision threshold on P(fake) and watch the confusions change (course Exp 2).")
    files = sorted((config.RESULTS_DIR / "preds").glob("*__test.npz"))
    if not files:
        st.info("No saved predictions yet. Run `python run_experiments.py` first."); st.stop()
    names = [f.name.replace("__test.npz", "") for f in files]
    pick = st.selectbox("Model", names, index=next((i for i, n in enumerate(names) if n.startswith("full_s")), 0))
    d = np.load(files[names.index(pick)])
    P, Y, classes = d["P"], d["Y"], [str(c) for c in d["classes"]]
    score, is_fake = fake_scores(P), Y != 0
    th = st.slider("Decision threshold", 0.05, 0.95, 0.5, 0.05)
    t = threshold_table(score, is_fake, [th])[0]
    a1, a2, a3, a4 = st.columns(4)
    a1.metric("Fakes caught (TPR)", f"{100 * t['tpr']:.1f}%"); a2.metric("Real flagged (FPR)", f"{100 * t['fpr']:.1f}%")
    a3.metric("Precision", f"{100 * t['precision']:.1f}%"); a4.metric("F1", f"{t['f1']:.3f}")
    left, right = st.columns(2)
    with left:
        st.markdown("**Confusion matrix (real vs any fake)**")
        st.dataframe(pd.DataFrame([[t["tn"], t["fp"]], [t["fn"], t["tp"]]], index=["true real", "true fake"], columns=["pred real", "pred fake"]))
        st.markdown("**Share of each true class flagged as fake**")
        st.dataframe(pd.DataFrame({"class": classes, "flagged as fake (%)": [round(100 * float((score[Y == k] >= th).mean()), 1) for k in range(len(classes))]}))
    with right:
        fpr, tpr, _ = roc_curve(is_fake, score)
        fig, ax = plt.subplots(1, 2, figsize=(9, 3.6))
        fig.patch.set_facecolor("#171e26")
        for a in ax:
            a.set_facecolor("#171e26")
            a.tick_params(colors="#c5ced6")
            a.xaxis.label.set_color("#c5ced6")
            a.yaxis.label.set_color("#c5ced6")
            a.title.set_color("#e8edf2")
            for spine in a.spines.values():
                spine.set_color("#42505d")
        ax[0].plot(fpr, tpr, color="#78aaa5", linewidth=2)
        ax[0].plot([0, 1], [0, 1], color="#82909b", linestyle="--", alpha=.5)
        ax[0].scatter([t["fpr"]], [t["tpr"]], color="#d8b77c", zorder=3)
        ax[0].set_title(f"ROC (AUC {roc_auc_score(is_fake, score):.3f})"); ax[0].set_xlabel("FPR"); ax[0].set_ylabel("TPR")
        for k, c in enumerate(classes):
            ax[1].hist(score[Y == k], bins=25, alpha=.55, label=c, edgecolor="none")
        ax[1].axvline(th, color="#d8b77c", linewidth=1.8); ax[1].set_title("score distribution"); ax[1].set_xlabel("P(fake)"); ax[1].legend()
        plt.tight_layout(); st.pyplot(fig); plt.close(fig)

# ---------------- results ----------------
elif page == "Results":
    st.title("Experiment results")
    summ, rob, kinds, raw = load_results()
    if summ.empty:
        st.info("No results yet. Run `python run_experiments.py` first."); st.stop()
    agg, disp = aggregate(summ)
    st.caption("All model numbers are mean ± std over random seeds.")
    st.subheader("1. Main comparison (3-class: real / GAN / manipulated)")
    mt = disp[(disp["eval"] == "test") & disp["base"].isin(MAIN_ORDER)].drop(columns=["eval"])
    st.dataframe(mt, use_container_width=True); show_fig("main_comparison.png")
    st.subheader("2. Convergence (Exp 1)")
    show_fig("convergence_epochs.png", "Validation loss/accuracy for different numbers of epochs")
    show_fig("convergence_arch.png", "Loss vs network architecture")
    st.subheader("3. Classification threshold & ROC (Exp 2)")
    show_fig("roc.png"); show_fig("threshold_sweep.png"); st.caption("Interactive version: 'Threshold analysis' page.")
    st.subheader("4. Autoencoder (Exp 3, 4)")
    ae = config.RESULTS_DIR / "autoencoder.json"
    if ae.exists():
        a = json.load(open(ae))
        st.dataframe(pd.DataFrame(a["classes"]).T.rename_axis("class"), use_container_width=True)
        st.write("AUC of reconstruction error as fake score:", a["auc_recon_error"])
        st.write("Classifier on original vs encoded input:", a["classifier_original_vs_encoded"])
        show_fig("ae_reconstruction.png"); show_fig("ae_mse_hist.png")
    st.subheader("5. Pre-trained VGG-16 features + clustering (Exp 7)")
    cl = config.RESULTS_DIR / "clustering.json"
    if cl.exists():
        st.write(json.load(open(cl)))
    for p in sorted(FIGS.glob("*_tsne.png")):
        show_fig(p.name)
    st.subheader("6. Fine-tuning: frozen vs scratch vs full (Exp 8, CO4)")
    show_csv("table_finetuning.csv")
    st.subheader("7. Regularization (CO3)")
    show_csv("table_regularization.csv"); show_fig("regularization.png")
    st.subheader("8. Preprocessing ablation")
    show_csv("table_preprocessing.csv")
    st.subheader("9. Robustness to JPEG / resize / noise")
    show_fig("robustness.png"); show_csv("table_robustness.csv")
    st.subheader("10. Cross-generator generalization")
    st.caption("Trained on ONE fake type; eval='test' = same type, eval='cross_*' = unseen type / generator.")
    show_csv("table_cross_generator.csv")
    show_csv("table_external_generators.csv", "Unseen external generators (e.g. StyleGAN)")
    show_fig("stylegan_truncation.png", "Detection AUC vs StyleGAN truncation")
    st.subheader("11. Localization & per-manipulation detection")
    show_csv("table_per_manipulation.csv")
    q = sorted(FIGS.glob("qualitative_*.png"))
    if q:
        st.image(str(q[0]), use_container_width=True)
    st.subheader("12. GAN (Exp 9, CO5)")
    show_fig("gan_samples.png", "top: real, bottom: DCGAN"); show_fig("gan_losses.png")
    gs = config.RUNS_DIR / "dcgan" / "gan_stats.json"
    if gs.exists():
        st.write(json.load(open(gs)))

# ---------------- dataset ----------------
else:
    st.title("Dataset explorer")
    mp = config.PROC_DIR / "meta.csv"
    if not mp.exists():
        st.info("Run `python -m src.data_prep` first."); st.stop()
    meta = pd.read_csv(mp).fillna("")
    rep = config.PROC_DIR / "data_report.json"
    if rep.exists():
        st.caption(f"Data report: {json.load(open(rep))}")
    st.subheader("Images per split / class")
    st.dataframe(meta.pivot_table(index="split", columns="cls", values="path", aggfunc="count", fill_value=0))
    st.subheader("Manipulation types")
    st.bar_chart(meta[meta["kind"] != ""]["kind"].value_counts())
    st.subheader("Preprocessing preview")
    sub = meta[(meta["split"] == "test") & (meta["cls"] == "real")]
    if not sub.empty:
        idx = st.number_input("Image index", 0, len(sub) - 1, 0)
        im = cv2.imread(str(config.PROC_DIR / sub.iloc[int(idx)]["path"]))
        cols = st.columns(len(config.PREPROC_MODES))
        for col, mode in zip(cols, config.PREPROC_MODES):
            col.image(cv2.cvtColor(apply_preproc(im, mode), cv2.COLOR_BGR2RGB), caption=mode, use_container_width=True)
    st.subheader("Random samples")
    split = st.selectbox("Split", ["train", "val", "test"], index=2)
    seed = st.number_input("Shuffle seed", 0, 9999, 0)
    for c in sorted(meta["cls"].unique()):
        sub = meta[(meta["split"] == split) & (meta["cls"] == c)]
        if sub.empty:
            continue
        st.markdown(f"**{c}**")
        cols = st.columns(6)
        for col, (_, r) in zip(cols, sub.sample(min(6, len(sub)), random_state=int(seed)).iterrows()):
            im = cv2.imread(str(config.PROC_DIR / r["path"]))
            if r["mask_path"]:
                mk = cv2.imread(str(config.PROC_DIR / r["mask_path"]), 0) / 255.0
                col.image(overlay(im, mk, 0.35), caption=f"{r['kind']} (edit in red)", use_container_width=True)
            else:
                col.image(cv2.cvtColor(im, cv2.COLOR_BGR2RGB), use_container_width=True)
