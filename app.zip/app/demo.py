"""RetiForGAN - simple demo.   streamlit run app/demo.py
One clean page: upload a fundus image -> verdict, edited-region map, Grad-CAM.
(The full research dashboard is still available: streamlit run app/dashboard.py)"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import cv2, numpy as np, pandas as pd, streamlit as st, torch
from src import config
from src.models import RetiForGAN
from src.utils import apply_preproc, bgr_to_tensor
from src.prep import prepare_bgr
from src.explain import analyze, overlay

st.set_page_config(page_title="RetiForGAN", page_icon="👁️", layout="centered")
LOW, HIGH = 0.30, 0.70          # demo thresholds on P(image is fake)
FAKE_NAMES = {"gan": "AI-generated", "manip": "edited / manipulated"}


@st.cache_resource
def load_model():
    cks = sorted(config.RUNS_DIR.glob("full_s*/best.pt"))
    if not cks:
        cks = sorted(p for p in config.RUNS_DIR.glob("*/best.pt") if p.parent.name != "dcgan")
    if not cks:
        return None, None, None
    ck = torch.load(cks[0], map_location="cpu", weights_only=False)
    c = ck["cfg"]
    m = RetiForGAN(c["arch"], c["num_classes"], c["use_freq"], c["use_mask"], pretrained=False, dropout=c.get("dropout", 0.3))
    m.load_state_dict(ck["state"]); m.eval()
    return m, {"classes": ck["classes"], "preproc": ck.get("preproc", "none"), "mean": ck.get("mean"), "std": ck.get("std")}, cks[0].parent.name


model, info, run_name = load_model()
st.title("👁️ RetiForGAN")
st.write("Is this retinal image **real**, **AI-generated** or **edited**?")
if model is None:
    st.error("No trained model found in runs/. Train one first."); st.stop()

mode = st.radio("Image source", ["Upload an image", "Test-set sample"], horizontal=True, label_visibility="collapsed")
img = None
if mode == "Upload an image":
    up = st.file_uploader("Upload a fundus image", type=["png", "jpg", "jpeg"])
    if up is not None:
        img = cv2.imdecode(np.frombuffer(up.getvalue(), np.uint8), cv2.IMREAD_COLOR)
        if img is None:
            st.error("Could not read that file.")
else:
    meta = pd.read_csv(config.PROC_DIR / "meta.csv").fillna("")
    t = meta[meta["split"] == "test"]
    c1, c2 = st.columns(2)
    cls = c1.selectbox("Class", sorted(t["cls"].unique()))
    idx = c2.number_input("Index", 0, int((t["cls"] == cls).sum()) - 1, 0)
    row = t[t["cls"] == cls].iloc[int(idx)]
    img = cv2.imread(str(config.PROC_DIR / row["path"]))
    st.caption(f"Ground truth: {row['cls']}" + (f" ({row['kind']})" if row["kind"] else ""))

if img is None:
    st.info("Upload an image to start."); st.stop()

base = prepare_bgr(img, config.IMG)
x = bgr_to_tensor(apply_preproc(base, info["preproc"]), info["mean"], info["std"])[None]
r = analyze(model, x)
classes, probs = info["classes"], r["probs"]
p_fake = float(1 - probs[classes.index("real")])
top = max((c for c in classes if c != "real"), key=lambda c: probs[classes.index(c)])

if p_fake < LOW:
    st.info("🔍 No known fake patterns found")
elif p_fake < HIGH:
    st.warning("⚠️ Uncertain: could be fake")
else:
    st.error(f"🚨 Likely fake: {FAKE_NAMES.get(top, top)}")
st.metric("Probability of a fake this model knows (GAN / edits)", f"{100 * p_fake:.0f}%")
h0, w0 = img.shape[:2]
if (h0, w0) != (config.IMG, config.IMG):
    st.warning(f"Your image is {w0}x{h0} and was shrunk to {config.IMG}x{config.IMG}, which removes fine detail. "
               "This model only learned fakes from one small GAN and synthetic edits, so a fake from another generator "
               "(diffusion models, ChatGPT-style image tools) can slip through as 'no fake patterns found'. "
               "This is a limitation of the model, not proof that the image is real.")

cols = st.columns(3)
cols[0].image(cv2.cvtColor(base, cv2.COLOR_BGR2RGB), caption="What the model sees", use_container_width=True)
if r["mask"] is not None:
    cols[1].image(overlay(base, r["mask"]), caption="Suspected edited region", use_container_width=True)
cols[2].image(overlay(base, r["cam"]), caption="Grad-CAM", use_container_width=True)

with st.expander("Details and limitations"):
    st.bar_chart(pd.Series(probs, index=classes))
    st.write(f"Model: `{run_name}`. Thresholds: below {LOW:.0%} authentic, above {HIGH:.0%} fake (demo settings).")
    st.write("This model was trained on 128 px images, fakes from one small GAN and synthetic circular edits. "
             "Images from other generators (diffusion, StyleGAN, ...) can be missed, and big photos lose fine detail "
             "when shrunk to 128 px. Research prototype, not a forensic or clinical tool.")
