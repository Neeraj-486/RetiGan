"""RetiForGAN dashboard.   streamlit run app/dashboard.py
Pages: Live detector | Batch scan | Threshold analysis | Results | Dataset"""
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import cv2, numpy as np, pandas as pd, streamlit as st, torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, roc_auc_score
from src import config
from src.models import RetiForGAN
from src.utils import preprocess_bgr, perturb, apply_preproc, bgr_to_tensor
from src.explain import analyze, overlay, spectrum_image
from src.make_report import load_results, aggregate, MAIN_ORDER
from src.metrics import fake_scores, threshold_table

st.set_page_config(page_title="RetiForGAN", page_icon="👁️", layout="wide")
FRIENDLY = {"real": "Authentic retinal image", "gan": "AI-generated (GAN)", "manip": "Manipulated / edited"}
FIGS = config.RESULTS_DIR / "figs"


def friendly(c):
    return FRIENDLY.get(c, f"AI-generated ({c.replace('ext_', '')})" if c.startswith("ext_") else c)


@st.cache_resource
def load_model(path):
    ck = torch.load(path, map_location="cpu", weights_only=False)          # our own checkpoints
    c = ck["cfg"]
    m = RetiForGAN(c["arch"], c["num_classes"], c["use_freq"], c["use_mask"], pretrained=False, dropout=c.get("dropout", 0.3))
    m.load_state_dict(ck["state"]); m.eval()
    return m, {"classes": ck["classes"], "cfg": c, "preproc": ck.get("preproc", "none"), "mean": ck.get("mean"), "std": ck.get("std")}


def decode(f):
    return cv2.imdecode(np.frombuffer(f.getvalue(), np.uint8), cv2.IMREAD_COLOR)


def prepare(img, info, jpeg_q=100, noise=0):
    """Same pipeline as training: base preprocessing -> optional degradation -> model preprocessing -> tensor."""
    base = preprocess_bgr(img, config.IMG)
    if jpeg_q < 100:
        base = perturb(base, "jpeg", jpeg_q)
    if noise > 0:
        base = perturb(base, "noise", noise)
    x = bgr_to_tensor(apply_preproc(base, info["preproc"]), info["mean"], info["std"])[None]
    return base, x


def show_fig(name, caption=None):
    p = FIGS / name
    if p.exists():
        st.image(str(p), caption=caption, use_container_width=True)


def show_csv(name, title=None):
    p = config.RESULTS_DIR / name
    if p.exists():
        if title:
            st.markdown(f"**{title}**")
        st.dataframe(pd.read_csv(p), use_container_width=True)


# ---------------- sidebar ----------------
st.sidebar.title("👁️ RetiForGAN")
st.sidebar.caption("Detecting AI-generated & manipulated retinal fundus images")
page = st.sidebar.radio("Page", ["Live detector", "Batch scan", "Threshold analysis", "Results", "Dataset"])
model = info = None
if page in ("Live detector", "Batch scan"):
    ckpts = sorted(config.RUNS_DIR.glob("*/best.pt"))
    ckpts = [p for p in ckpts if p.parent.name != "dcgan"]
    if not ckpts:
        st.sidebar.warning("No trained checkpoints in runs/ yet.")
    else:
        names = [p.parent.name for p in ckpts]
        default = next((i for i, n in enumerate(names) if n.startswith("full_s")), 0)
        sel = st.sidebar.selectbox("Model", names, index=default)
        model, info = load_model(str(config.RUNS_DIR / sel / "best.pt"))
        c = info["cfg"]
        st.sidebar.caption(f"{c['arch']} | frequency stream: {c['use_freq']} | localization head: {c['use_mask']} | preprocessing: {info['preproc']}")

# ---------------- live detector ----------------
if page == "Live detector":
    st.title("Live detector")
    if model is None:
        st.stop()
    classes = info["classes"]
    c1, c2 = st.columns([1, 2])
    with c1:
        up = st.file_uploader("Upload a fundus image", type=["png", "jpg", "jpeg"])
        sample, meta_p = None, config.PROC_DIR / "meta.csv"
        if meta_p.exists():
            t = pd.read_csv(meta_p).fillna(""); t = t[t["split"] == "test"]
            st.caption("...or pick a test-set sample")
            sc = st.selectbox("Class", sorted(t["cls"].unique()))
            si = st.number_input("Index", 0, int((t["cls"] == sc).sum()) - 1, 0)
            sample = t[t["cls"] == sc].iloc[int(si)]
        st.markdown("**Stress test** (simulate real-world degradation)")
        jq = st.slider("JPEG quality", 20, 100, 100)
        nz = st.slider("Gaussian noise (sigma)", 0, 15, 0)
    img = decode(up) if up is not None else (cv2.imread(str(config.PROC_DIR / sample["path"])) if sample is not None else None)
    if up is None and sample is not None:
        c1.caption(f"Ground truth: **{sample['cls']}**" + (f" ({sample['kind']})" if sample["kind"] else ""))
    if img is None:
        st.info("Upload an image or choose a sample."); st.stop()
    base, x = prepare(img, info, jq, nz)
    r = analyze(model, x)
    probs = pd.Series(r["probs"], index=[friendly(c) for c in classes])
    verdict = classes[r["pred"]]
    with c2:
        m1, m2, m3 = st.columns(3)
        m1.metric("Verdict", friendly(verdict)); m2.metric("Confidence", f"{100 * probs.max():.1f}%")
        m3.metric("P(any fake)", f"{100 * (1 - r['probs'][classes.index('real')]):.1f}%")
        (st.success if verdict == "real" else st.error)(
            "No manipulation evidence found." if verdict == "real" else "Evidence of synthetic content or editing.")
        st.bar_chart(probs)
    cols = st.columns(4)
    cols[0].image(cv2.cvtColor(base, cv2.COLOR_BGR2RGB), caption="Input (preprocessed)", use_container_width=True)
    if r["mask"] is not None:
        cols[1].image(overlay(base, r["mask"]), caption="Predicted edited region", use_container_width=True)
    else:
        cols[1].info("This model has no localization head. Pick a 'full' or 'rgb_mask' run.")
    cols[2].image(overlay(base, r["cam"]), caption="Grad-CAM (what the classifier used)", use_container_width=True)
    cols[3].image(spectrum_image(base), caption="Fourier spectrum", use_container_width=True)
    st.caption("Research prototype for a student project. Not a clinical or forensic tool.")

# ---------------- batch scan ----------------
elif page == "Batch scan":
    st.title("Batch scan")
    if model is None:
        st.stop()
    classes = info["classes"]
    files = st.file_uploader("Upload several images", type=["png", "jpg", "jpeg"], accept_multiple_files=True)
    if files:
        rows, bar = [], st.progress(0.0)
        for i, f in enumerate(files):
            img = decode(f)
            if img is None:
                continue
            with torch.no_grad():
                p = torch.softmax(model(prepare(img, info)[1])["logits"], 1)[0].numpy()
            rows.append({"file": f.name, "verdict": friendly(classes[int(p.argmax())]),
                         **{f"P({c})": round(float(v), 3) for c, v in zip(classes, p)},
                         "P(any fake)": round(float(1 - p[classes.index("real")]), 3)})
            bar.progress((i + 1) / len(files))
        df = pd.DataFrame(rows)
        st.dataframe(df, use_container_width=True)
        st.download_button("Download CSV", df.to_csv(index=False), "retiforgan_scan.csv", "text/csv")
        st.bar_chart(df["verdict"].value_counts())

# ---------------- threshold analysis ----------------
elif page == "Threshold analysis":
    st.title("Threshold analysis")
    st.caption("Move the decision threshold on P(fake) and watch the confusions change (course Exp 2).")
    files = sorted((config.RESULTS_DIR / "preds").glob("*__test.npz"))
    if not files:
        st.info("No saved predictions yet. Run `python run_experiments.py` first."); st.stop()
    names = [f.name.replace("__test.npz", "") for f in files]
    pick = st.selectbox("Model", names, index=next((i for i, n in enumerate(names) if n.startswith("full_s")), 0))
    d = np.load(files[names.index(pick)])
    P, Y, classes = d["P"], d["Y"], [str(c) for c in d["classes"]]
    score, is_fake = fake_scores(P), Y != 0
    th = st.slider("Decision threshold", 0.05, 0.95, 0.5, 0.05)
    t = threshold_table(score, is_fake, [th])[0]
    a1, a2, a3, a4 = st.columns(4)
    a1.metric("Fakes caught (TPR)", f"{100 * t['tpr']:.1f}%"); a2.metric("Real flagged (FPR)", f"{100 * t['fpr']:.1f}%")
    a3.metric("Precision", f"{100 * t['precision']:.1f}%"); a4.metric("F1", f"{t['f1']:.3f}")
    left, right = st.columns(2)
    with left:
        st.markdown("**Confusion matrix (real vs any fake)**")
        st.dataframe(pd.DataFrame([[t["tn"], t["fp"]], [t["fn"], t["tp"]]], index=["true real", "true fake"], columns=["pred real", "pred fake"]))
        st.markdown("**Share of each true class flagged as fake**")
        st.dataframe(pd.DataFrame({"class": classes, "flagged as fake (%)": [round(100 * float((score[Y == k] >= th).mean()), 1) for k in range(len(classes))]}))
    with right:
        fpr, tpr, _ = roc_curve(is_fake, score)
        fig, ax = plt.subplots(1, 2, figsize=(9, 3.6))
        ax[0].plot(fpr, tpr); ax[0].plot([0, 1], [0, 1], "k--", alpha=.4); ax[0].scatter([t["fpr"]], [t["tpr"]], c="red", zorder=3)
        ax[0].set_title(f"ROC (AUC {roc_auc_score(is_fake, score):.3f})"); ax[0].set_xlabel("FPR"); ax[0].set_ylabel("TPR")
        for k, c in enumerate(classes):
            ax[1].hist(score[Y == k], bins=25, alpha=.5, label=c)
        ax[1].axvline(th, c="red"); ax[1].set_title("score distribution"); ax[1].set_xlabel("P(fake)"); ax[1].legend()
        plt.tight_layout(); st.pyplot(fig)

# ---------------- results ----------------
elif page == "Results":
    st.title("Experiment results")
    summ, rob, kinds, raw = load_results()
    if summ.empty:
        st.info("No results yet. Run `python run_experiments.py` first."); st.stop()
    agg, disp = aggregate(summ)
    st.caption("All model numbers are mean ± std over random seeds.")
    st.subheader("1. Main comparison (3-class: real / GAN / manipulated)")
    mt = disp[(disp["eval"] == "test") & disp["base"].isin(MAIN_ORDER)].drop(columns=["eval"])
    st.dataframe(mt, use_container_width=True); show_fig("main_comparison.png")
    st.subheader("2. Convergence (Exp 1)")
    show_fig("convergence_epochs.png", "Validation loss/accuracy for different numbers of epochs")
    show_fig("convergence_arch.png", "Loss vs network architecture")
    st.subheader("3. Classification threshold & ROC (Exp 2)")
    show_fig("roc.png"); show_fig("threshold_sweep.png"); st.caption("Interactive version: 'Threshold analysis' page.")
    st.subheader("4. Autoencoder (Exp 3, 4)")
    ae = config.RESULTS_DIR / "autoencoder.json"
    if ae.exists():
        a = json.load(open(ae))
        st.dataframe(pd.DataFrame(a["classes"]).T.rename_axis("class"), use_container_width=True)
        st.write("AUC of reconstruction error as fake score:", a["auc_recon_error"])
        st.write("Classifier on original vs encoded input:", a["classifier_original_vs_encoded"])
        show_fig("ae_reconstruction.png"); show_fig("ae_mse_hist.png")
    st.subheader("5. Pre-trained VGG-16 features + clustering (Exp 7)")
    cl = config.RESULTS_DIR / "clustering.json"
    if cl.exists():
        st.write(json.load(open(cl)))
    for p in sorted(FIGS.glob("*_tsne.png")):
        show_fig(p.name)
    st.subheader("6. Fine-tuning: frozen vs scratch vs full (Exp 8, CO4)")
    show_csv("table_finetuning.csv")
    st.subheader("7. Regularization (CO3)")
    show_csv("table_regularization.csv"); show_fig("regularization.png")
    st.subheader("8. Preprocessing ablation")
    show_csv("table_preprocessing.csv")
    st.subheader("9. Robustness to JPEG / resize / noise")
    show_fig("robustness.png"); show_csv("table_robustness.csv")
    st.subheader("10. Cross-generator generalization")
    st.caption("Trained on ONE fake type; eval='test' = same type, eval='cross_*' = unseen type / generator.")
    show_csv("table_cross_generator.csv")
    show_csv("table_external_generators.csv", "Unseen external generators (e.g. StyleGAN)")
    show_fig("stylegan_truncation.png", "Detection AUC vs StyleGAN truncation")
    st.subheader("11. Localization & per-manipulation detection")
    show_csv("table_per_manipulation.csv")
    q = sorted(FIGS.glob("qualitative_*.png"))
    if q:
        st.image(str(q[0]), use_container_width=True)
    st.subheader("12. GAN (Exp 9, CO5)")
    show_fig("gan_samples.png", "top: real, bottom: DCGAN"); show_fig("gan_losses.png")
    gs = config.RUNS_DIR / "dcgan" / "gan_stats.json"
    if gs.exists():
        st.write(json.load(open(gs)))

# ---------------- dataset ----------------
else:
    st.title("Dataset explorer")
    mp = config.PROC_DIR / "meta.csv"
    if not mp.exists():
        st.info("Run `python -m src.data_prep` first."); st.stop()
    meta = pd.read_csv(mp).fillna("")
    rep = config.PROC_DIR / "data_report.json"
    if rep.exists():
        st.caption(f"Data report: {json.load(open(rep))}")
    st.subheader("Images per split / class")
    st.dataframe(meta.pivot_table(index="split", columns="cls", values="path", aggfunc="count", fill_value=0))
    st.subheader("Manipulation types")
    st.bar_chart(meta[meta["kind"] != ""]["kind"].value_counts())
    st.subheader("Preprocessing preview")
    sub = meta[(meta["split"] == "test") & (meta["cls"] == "real")]
    if not sub.empty:
        idx = st.number_input("Image index", 0, len(sub) - 1, 0)
        im = cv2.imread(str(config.PROC_DIR / sub.iloc[int(idx)]["path"]))
        cols = st.columns(len(config.PREPROC_MODES))
        for col, mode in zip(cols, config.PREPROC_MODES):
            col.image(cv2.cvtColor(apply_preproc(im, mode), cv2.COLOR_BGR2RGB), caption=mode, use_container_width=True)
    st.subheader("Random samples")
    split = st.selectbox("Split", ["train", "val", "test"], index=2)
    seed = st.number_input("Shuffle seed", 0, 9999, 0)
    for c in sorted(meta["cls"].unique()):
        sub = meta[(meta["split"] == split) & (meta["cls"] == c)]
        if sub.empty:
            continue
        st.markdown(f"**{c}**")
        cols = st.columns(6)
        for col, (_, r) in zip(cols, sub.sample(min(6, len(sub)), random_state=int(seed)).iterrows()):
            im = cv2.imread(str(config.PROC_DIR / r["path"]))
            if r["mask_path"]:
                mk = cv2.imread(str(config.PROC_DIR / r["mask_path"]), 0) / 255.0
                col.image(overlay(im, mk, 0.35), caption=f"{r['kind']} (edit in red)", use_container_width=True)
            else:
                col.image(cv2.cvtColor(im, cv2.COLOR_BGR2RGB), use_container_width=True)
